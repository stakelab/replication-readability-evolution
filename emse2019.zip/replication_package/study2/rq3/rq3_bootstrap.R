###### MARKOV CHAIN
library(boot)
library(markovchain)
library(devtools)
library(BBmisc)
library(diagram)
library(igraph)

norm<-function(x){
  for(i in 1:nrow(x)){
    sumRow <- sum(x[i,])
    for(j in 1:ncol(x)){
      if(sumRow == 0){
        x[i, j] <- 0
      } else {
        x[i, j] <- x[i, j]/sumRow
      }
      
    }
  }
  x
}


stratified_sample <- read.csv("study1/rq2/rq2.csv", sep = ",", stringsAsFactors = FALSE)

#ACCURACY OF THE TOOLs
#calculate the percentage of agree and disagree
readable_unreadable <- stratified_sample[(stratified_sample$from_state == "readable") & (stratified_sample$to_state == "unreadable"), ]
readable_readable <- stratified_sample[(stratified_sample$from_state == "readable") & (stratified_sample$to_state == "readable"), ]
unreadable_readable <- stratified_sample[(stratified_sample$from_state == "unreadable") & (stratified_sample$to_state == "readable"), ]
unreadable_unreadable <- stratified_sample[(stratified_sample$from_state == "unreadable") & (stratified_sample$to_state == "unreadable"), ]
created_readable <- stratified_sample[(stratified_sample$from_state == "created") & (stratified_sample$to_state == "readable"), ]
created_unreadable <- stratified_sample[(stratified_sample$from_state == "created") & (stratified_sample$to_state == "unreadable"), ]
renamed_readable <- stratified_sample[(stratified_sample$from_state == "renamed") & (stratified_sample$to_state == "readable"), ]
renamed_unreadable <- stratified_sample[(stratified_sample$from_state == "renamed") & (stratified_sample$to_state == "unreadable"), ]

num_transition_tot <- (nrow(readable_readable) + nrow(readable_unreadable) + nrow(unreadable_readable) + nrow(unreadable_unreadable)) * 2

num_agree_R_U <- length(which(readable_unreadable$Definitive.pre == "AGREE")) + length(which(readable_unreadable$Definitive.post == "AGREE"))
num_agree_R_R <- length(which(readable_readable$Definitive.pre == "AGREE")) + length(which(readable_readable$Definitive.post == "AGREE"))
num_agree_U_R <- length(which(unreadable_readable$Definitive.pre == "AGREE")) + length(which(unreadable_readable$Definitive.post == "AGREE"))
num_agree_U_U <- length(which(unreadable_unreadable$Definitive.pre == "AGREE")) + length(which(unreadable_unreadable$Definitive.post == "AGREE"))

num_agree_tot <- num_agree_R_U + num_agree_R_R + num_agree_U_R + num_agree_U_U

num_disagree_R_U <- length(which(readable_unreadable$Definitive.pre == "DISAGREE")) + length(which(readable_unreadable$Definitive.post == "DISAGREE"))
num_disagree_R_R <- length(which(readable_readable$Definitive.pre == "DISAGREE")) + length(which(readable_readable$Definitive.post == "DISAGREE"))
num_disagree_U_R <- length(which(unreadable_readable$Definitive.pre == "DISAGREE")) + length(which(unreadable_readable$Definitive.post == "DISAGREE"))
num_disagree_U_U <- length(which(unreadable_unreadable$Definitive.pre == "DISAGREE")) + length(which(unreadable_unreadable$Definitive.post == "DISAGREE"))

num_disagree_tot <- num_disagree_R_U + num_disagree_R_R + num_disagree_U_R + num_disagree_U_U

percentage_agree <- num_agree_tot/num_transition_tot
percentage_agree
#agree: 82%
percentage_disagree <- num_disagree_tot/num_transition_tot
percentage_disagree
#disagree: 17%

error_for_transition <- data.frame(from_state = character(),
                                   to_state = character(),
                                   error = numeric(),
                                   stringsAsFactors = FALSE)
error_for_transition[1, ] <- c(from_state = "readable", to_state = "readable", error = 0.00)
error_for_transition[2, ] <- c(from_state = "readable", to_state = "unreadable", error = 0.00)
error_for_transition[3, ] <- c(from_state = "unreadable", to_state = "readable", error = 0.00)
error_for_transition[4, ] <- c(from_state = "unreadable", to_state = "unreadable", error = 0.00)
error_for_transition[5, ] <- c(from_state = "created", to_state = "readable", error = 0.00)
error_for_transition[6, ] <- c(from_state = "created", to_state = "unreadable", error = 0.00)
error_for_transition[7, ] <- c(from_state = "renamed", to_state = "readable", error = 0.00)
error_for_transition[8, ] <- c(from_state = "renamed", to_state = "unreadable", error = 0.00)
error_for_transition$num_occurences <- 0
error_for_transition$num_disagree <- 0

for(i in 1:nrow(error_for_transition)){
  error_for_transition$num_occurences[i] <- length(which((stratified_sample$from_state == error_for_transition$from_state[i]) & (stratified_sample$to_state == error_for_transition$to_state[i])))
}

for(i in 1:nrow(error_for_transition)){
  
  dataset <- stratified_sample[(stratified_sample$from_state == error_for_transition$from_state[i]) & (stratified_sample$to_state == error_for_transition$to_state[i]), ]
  print(i)
  print(error_for_transition$from_state[i])
  print(error_for_transition$to_state[i])
  
  for(j in 1:nrow(dataset)){
    if((dataset$Definitive.pre[j] == "DISAGREE") || (dataset$Definitive.post[j] == "DISAGREE")){
      error_for_transition$num_disagree[i] <- error_for_transition$num_disagree[i] + 1  
    }
    
  }
  print(error_for_transition$num_disagree[i])
  error_for_transition$error[i] <- error_for_transition$num_disagree[i]/error_for_transition$num_occurences[i]
}

#####Confusion matrix
stratified_sample$state_real_pre <- NA
stratified_sample$state_real_post <- NA
for(i in 1:nrow(stratified_sample)){
  if((stratified_sample$from_state[i] == "created") || (stratified_sample$from_state[i] == "renamed")){
    stratified_sample$state_real_pre[i] <- stratified_sample$from_state[i]
  }
  
  if((stratified_sample$from_state[i] == "readable") && (stratified_sample$Definitive.pre[i] == "AGREE")){
    stratified_sample$state_real_pre[i] <- "readable"
  } else {
    if((stratified_sample$from_state[i] == "readable") && (stratified_sample$Definitive.pre[i] == "DISAGREE")){
      stratified_sample$state_real_pre[i] <- "unreadable" 
    } else {
      if((stratified_sample$from_state[i] == "unreadable") && (stratified_sample$Definitive.pre[i] == "AGREE")){
        stratified_sample$state_real_pre[i] <- "unreadable"
      } else {
        if((stratified_sample$from_state[i] == "unreadable") && (stratified_sample$Definitive.pre[i] == "DISAGREE")){
          stratified_sample$state_real_pre[i] <- "readable"
        }
      }
    }
  }
  
  if((stratified_sample$to_state[i] == "readable") && (stratified_sample$Definitive.post[i] == "AGREE")){
    stratified_sample$state_real_post[i] <- "readable"
  } else {
    if((stratified_sample$to_state[i] == "readable") && (stratified_sample$Definitive.post[i] == "DISAGREE")){
      stratified_sample$state_real_post[i] <- "unreadable" 
    } else {
      if((stratified_sample$to_state[i] == "unreadable") && (stratified_sample$Definitive.post[i] == "AGREE")){
        stratified_sample$state_real_post[i] <- "unreadable"
      } else {
        if((stratified_sample$to_state[i] == "unreadable") && (stratified_sample$Definitive.post[i] == "DISAGREE")){
          stratified_sample$state_real_post[i] <- "readable"
        }
      }
    }
  }
}

stratified_sample$label_actual <- NA
stratified_sample$label_real <- NA

for(i in 1:nrow(stratified_sample)){
  if(stratified_sample$from_state[i] == "created"){
    if(stratified_sample$to_state[i] == "readable"){
      stratified_sample$label_actual[i] <- "c-r"
    } else {
      if(stratified_sample$to_state[i] == "unreadable"){
        stratified_sample$label_actual[i] <- "c-u"
      } 
    }
  } else {
    if(stratified_sample$from_state[i] == "renamed"){
      if(stratified_sample$to_state[i] == "readable"){
        stratified_sample$label_actual[i] <- "n-r"
      } else {
        if(stratified_sample$to_state[i] == "unreadable"){
          stratified_sample$label_actual[i] <- "n-u"
        } 
      }
    } else {
      if(stratified_sample$from_state[i] == "readable"){
        if(stratified_sample$to_state[i] == "readable"){
          stratified_sample$label_actual[i] <- "r-r"
        } else {
          if(stratified_sample$to_state[i] == "unreadable"){
            stratified_sample$label_actual[i] <- "r-u"
          } 
        }
      } else {
        if(stratified_sample$from_state[i] == "unreadable"){
          if(stratified_sample$to_state[i] == "readable"){
            stratified_sample$label_actual[i] <- "u-r"
          } else {
            if(stratified_sample$to_state[i] == "unreadable"){
              stratified_sample$label_actual[i] <- "u-u"
            } 
          }
        }
      }
    }
  }
  
  if(stratified_sample$state_real_pre[i] == "created"){
    if(stratified_sample$state_real_post[i] == "readable"){
      stratified_sample$label_real[i] <- "c-r"
    } else {
      if(stratified_sample$state_real_post[i] == "unreadable"){
        stratified_sample$label_real[i] <- "c-u"
      } 
    }
  } else {
    if(stratified_sample$state_real_pre[i] == "renamed"){
      if(stratified_sample$state_real_post[i] == "readable"){
        stratified_sample$label_real[i] <- "n-r"
      } else {
        if(stratified_sample$state_real_post[i] == "unreadable"){
          stratified_sample$label_real[i] <- "n-u"
        } 
      }
    } else {
      if(stratified_sample$state_real_pre[i] == "readable"){
        if(stratified_sample$state_real_post[i] == "readable"){
          stratified_sample$label_real[i] <- "r-r"
        } else {
          if(stratified_sample$state_real_post[i] == "unreadable"){
            stratified_sample$label_real[i] <- "r-u"
          } 
        }
      } else {
        if(stratified_sample$state_real_pre[i] == "unreadable"){
          if(stratified_sample$state_real_post[i] == "readable"){
            stratified_sample$label_real[i] <- "u-r"
          } else {
            if(stratified_sample$state_real_post[i] == "unreadable"){
              stratified_sample$label_real[i] <- "u-u"
            } 
          }
        }
      }
    }
  }
}

matrix <- matrix(data = c(rep(0, 64)), byrow = T, ncol = 8)
row.names(matrix) <- c("r-r", "r-u", "u-r", "u-u", "c-r", "c-u", "n-r", "n-u")
colnames(matrix) <- c("r-r", "r-u", "u-r", "u-u", "c-r", "c-u", "n-r", "n-u")
matrix

for(i in 1:nrow(stratified_sample)){
  matrix[stratified_sample$label_actual[i], stratified_sample$label_real[i]] <- matrix[stratified_sample$label_actual[i], stratified_sample$label_real[i]] + 1
}

precision_total <- data.frame(label_transition1 = character(),
                              label_transition2 = character(),
                              precision = numeric(),
                              stringsAsFactors = FALSE)
precision_row <- data.frame(label_transition1 = character(),
                            label_transition2 = character(),
                            precision = numeric(),
                            stringsAsFactors = FALSE)


recall_total <- data.frame(label_transition1 = character(),
                           label_transition2 = character(),
                           recall = numeric(),
                           stringsAsFactors = FALSE)
recall_row <- data.frame(label_transition1 = character(),
                         label_transition2 = character(),
                         recall = numeric(),
                         stringsAsFactors = FALSE)

fmeasure_total <- data.frame(label_transition1 = character(),
                             label_transition2 = character(),
                             fmeasure = numeric(),
                             stringsAsFactors = FALSE)
fmeasure_row <- data.frame(label_transition1 = character(),
                           label_transition2 = character(),
                           fmeasure = numeric(),
                           stringsAsFactors = FALSE)


labels <- c("r-r", "r-u", "u-r", "u-u", "c-r", "c-u", "n-r", "n-u")
labels1 <- c("r-r", "r-u", "u-r", "u-u", "c-r", "c-u", "n-r", "n-u")

for(i in 1:length(labels)){
  for(j in 1:length(labels1)){
    precision_row[1, ] <- c(labels[i], labels1[j], 0.00)
    precision_total <- rbind(precision_total, precision_row)
    recall_row[1, ] <- c(labels[i], labels1[j], 0.00)
    recall_total <- rbind(recall_total, recall_row)
    fmeasure_row[1, ] <- c(labels[i], labels1[j], 0.00)
    fmeasure_total <- rbind(fmeasure_total, fmeasure_row)
  }
}

for(i in 1:length(labels)){
  for(j in 1:length(labels1)){
    tp <- matrix[i, j]
    fp <- sum(matrix[i, ]) - tp
    fn <- sum(matrix[, j]) - tp
    k1 <- which((precision_total$label_transition1 == labels[i]) & (precision_total$label_transition2 == labels1[j]))
    precision_total$precision[k1] <- tp/(tp+fp)
    k2 <- which((recall_total$label_transition1 == labels[i]) & (recall_total$label_transition2 == labels1[j]))
    recall_total$recall[k2] <- tp/(tp+fn)
    k3 <- which((fmeasure_total$label_transition1 == labels[i]) & (fmeasure_total$label_transition2 == labels1[j]))
    fmeasure_total$fmeasure[k3] <- 2*((as.numeric(precision_total$precision[k1]) * as.numeric(recall_total$recall[k2])) / (as.numeric(precision_total$precision[k1]) + as.numeric(recall_total$recall[k2])))
  }
}
confusion_matrix_stratified_sample <- matrix

##### (RANDOM)
#Prepare percentages of confusion matrix in table 
percentages_confusion_matrix_stratified_sample <- norm(confusion_matrix_stratified_sample)
df_percentages <- as.data.frame(as.table(percentages_confusion_matrix_stratified_sample))
names(df_percentages)[1] <- "tool"
names(df_percentages)[2] <- "our_evaluation"
names(df_percentages)[3] <- "percentages"
df_percentages$tool_from_state <- NA
df_percentages$tool_to_state <- NA
df_percentages$our_evaluation_from_state <- NA
df_percentages$our_evaluation_to_state <- NA
df_percentages$percentages.1 <- 0.00

attach(df_percentages)
df_percentages$tool_from_state[tool == "r-r" | tool == "r-u"] <- "readable"
df_percentages$tool_from_state[tool == "u-r" | tool == "u-u"] <- "unreadable"
df_percentages$tool_from_state[tool == "c-r" | tool == "c-u"] <- "created"
df_percentages$tool_from_state[tool == "n-r" | tool == "n-u"] <- "renamed"

df_percentages$tool_to_state[tool == "r-r" | tool == "u-r" | tool == "c-r" | tool == "n-r"] <- "readable"
df_percentages$tool_to_state[tool == "r-u" | tool == "u-u" | tool == "c-u" | tool == "n-u"] <- "unreadable"

df_percentages$our_evaluation_from_state[our_evaluation == "r-r" | our_evaluation == "r-u"] <- "readable"
df_percentages$our_evaluation_from_state[our_evaluation == "u-r" | our_evaluation == "u-u"] <- "unreadable"
df_percentages$our_evaluation_from_state[our_evaluation == "c-r" | our_evaluation == "c-u"] <- "created"
df_percentages$our_evaluation_from_state[our_evaluation == "n-r" | our_evaluation == "n-u"] <- "renamed"

df_percentages$our_evaluation_to_state[our_evaluation == "r-r" | our_evaluation == "u-r" | our_evaluation == "c-r" | our_evaluation == "n-r"] <- "readable"
df_percentages$our_evaluation_to_state[our_evaluation == "r-u" | our_evaluation == "u-u" | our_evaluation == "c-u" | our_evaluation == "n-u"] <- "unreadable"

df_percentages$percentages.1[tool ==  "r-r" & our_evaluation == "r-r"] <- df_percentages$percentages[tool == "r-r" & our_evaluation == "r-r"]
df_percentages$percentages.1[tool ==  "r-r" & our_evaluation == "r-u"] <- df_percentages$percentages.1[tool ==  "r-r" & our_evaluation == "r-r"] + df_percentages$percentages[tool == "r-r" & our_evaluation == "r-u"]
df_percentages$percentages.1[tool ==  "r-r" & our_evaluation == "u-r"] <- df_percentages$percentages.1[tool ==  "r-r" & our_evaluation == "r-u"] + df_percentages$percentages[tool == "r-r" & our_evaluation == "u-r"]
df_percentages$percentages.1[tool ==  "r-r" & our_evaluation == "u-u"] <- df_percentages$percentages.1[tool ==  "r-r" & our_evaluation == "u-r"] + df_percentages$percentages[tool == "r-r" & our_evaluation == "u-u"]

df_percentages$percentages.1[tool ==  "r-u" & our_evaluation == "r-r"] <- df_percentages$percentages[tool == "r-u" & our_evaluation == "r-r"]
df_percentages$percentages.1[tool ==  "r-u" & our_evaluation == "r-u"] <- df_percentages$percentages.1[tool ==  "r-u" & our_evaluation == "r-r"] + df_percentages$percentages[tool == "r-u" & our_evaluation == "r-u"]
df_percentages$percentages.1[tool ==  "r-u" & our_evaluation == "u-r"] <- df_percentages$percentages.1[tool ==  "r-u" & our_evaluation == "r-u"] + df_percentages$percentages[tool == "r-u" & our_evaluation == "u-r"]
df_percentages$percentages.1[tool ==  "r-u" & our_evaluation == "u-u"] <- df_percentages$percentages.1[tool ==  "r-u" & our_evaluation == "u-r"] + df_percentages$percentages[tool == "r-u" & our_evaluation == "u-u"]

df_percentages$percentages.1[tool ==  "u-r" & our_evaluation == "r-r"] <- df_percentages$percentages[tool == "u-r" & our_evaluation == "r-r"]
df_percentages$percentages.1[tool ==  "u-r" & our_evaluation == "r-u"] <- df_percentages$percentages.1[tool ==  "u-r" & our_evaluation == "r-r"] + df_percentages$percentages[tool == "u-r" & our_evaluation == "r-u"]
df_percentages$percentages.1[tool ==  "u-r" & our_evaluation == "u-r"] <- df_percentages$percentages.1[tool ==  "u-r" & our_evaluation == "r-u"] + df_percentages$percentages[tool == "u-r" & our_evaluation == "u-r"]
df_percentages$percentages.1[tool ==  "u-r" & our_evaluation == "u-u"] <- df_percentages$percentages.1[tool ==  "u-r" & our_evaluation == "u-r"] + df_percentages$percentages[tool == "u-r" & our_evaluation == "u-u"]

df_percentages$percentages.1[tool ==  "u-u" & our_evaluation == "r-r"] <- df_percentages$percentages[tool == "u-u" & our_evaluation == "r-r"]
df_percentages$percentages.1[tool ==  "u-u" & our_evaluation == "r-u"] <- df_percentages$percentages.1[tool ==  "u-u" & our_evaluation == "r-r"] + df_percentages$percentages[tool == "u-u" & our_evaluation == "r-u"]
df_percentages$percentages.1[tool ==  "u-u" & our_evaluation == "u-r"] <- df_percentages$percentages.1[tool ==  "u-u" & our_evaluation == "r-u"] + df_percentages$percentages[tool == "u-u" & our_evaluation == "u-r"]
df_percentages$percentages.1[tool ==  "u-u" & our_evaluation == "u-u"] <- df_percentages$percentages.1[tool ==  "u-u" & our_evaluation == "u-r"] + df_percentages$percentages[tool == "u-u" & our_evaluation == "u-u"]

df_percentages$percentages.1[tool ==  "c-r" & our_evaluation == "c-r"] <- df_percentages$percentages[tool == "c-r" & our_evaluation == "c-r"]
df_percentages$percentages.1[tool ==  "c-r" & our_evaluation == "c-u"] <- df_percentages$percentages.1[tool ==  "c-r" & our_evaluation == "c-r"] + df_percentages$percentages[tool == "c-r" & our_evaluation == "c-u"]

df_percentages$percentages.1[tool ==  "c-u" & our_evaluation == "c-r"] <- df_percentages$percentages[tool == "c-u" & our_evaluation == "c-r"]
df_percentages$percentages.1[tool ==  "c-u" & our_evaluation == "c-u"] <- df_percentages$percentages.1[tool ==  "c-u" & our_evaluation == "c-r"] + df_percentages$percentages[tool == "c-u" & our_evaluation == "c-u"]

df_percentages$percentages.1[tool ==  "n-r" & our_evaluation == "n-r"] <- df_percentages$percentages[tool == "n-r" & our_evaluation == "n-r"]
df_percentages$percentages.1[tool ==  "n-r" & our_evaluation == "n-u"] <- df_percentages$percentages.1[tool ==  "n-r" & our_evaluation == "n-r"] + df_percentages$percentages[tool == "n-r" & our_evaluation == "n-u"]

df_percentages$percentages.1[tool ==  "n-u" & our_evaluation == "n-r"] <- df_percentages$percentages[tool == "n-u" & our_evaluation == "n-r"]
df_percentages$percentages.1[tool ==  "n-u" & our_evaluation == "n-u"] <- df_percentages$percentages.1[tool ==  "n-u" & our_evaluation == "n-r"] + df_percentages$percentages[tool == "n-u" & our_evaluation == "n-u"]
detach()

newTransitionOrdered <- read.csv("study2/our_dataset_filtered.csv")

row <- data.frame(name_project = character(),
                  from_state = character(),
                  to_state = character(),
                  occurences = numeric(),
                  stringsAsFactors = FALSE)
bootstrap_mean <- data.frame(project = character(),
                             from_state = character(), 
                             to_state = character(),
                             low_quantile = numeric(),
                             high_quantile = numeric(),
                             bootstrap_mean = numeric(), 
                             stringsAsFactors = FALSE)
row1 <- data.frame(project = character(),
                   from_state = character(), 
                   to_state = character(),
                   low_quantile = numeric(),
                   high_quantile = numeric(),
                   bootstrap_mean = numeric(), 
                   stringsAsFactors = FALSE)
all_state_transitions <- c("created", "readable", "unreadable", "renamed")
list_projects <- unique(newTransitionOrdered$project)
list_projects <- as.character(list_projects)
for(i in 1:length(list_projects)){
  num_repetitions <- 10000
  project <- list_projects[[i]]
  print(project)
  
  #select subsample of the dataset on the single project
  dataset <- newTransitionOrdered[newTransitionOrdered$project == project, ]
  
  st_bootstrap <- data.frame(name_project = character(),
                             from_state = character(),
                             to_state = character(),
                             occurences = numeric(),
                             stringsAsFactors = FALSE)
  
  for(j in 1:length(all_state_transitions)){
    for(k in 1:length(all_state_transitions)){
      row[1, ] <- c(name_project = as.character(project),
                    from_state = as.character(all_state_transitions[j]),
                    to_state = as.character(all_state_transitions[k]),
                    occurences = 0)
      st_bootstrap = rbind(st_bootstrap, row)
    }
  }
  
  for(j in 1:10000){
    subsample <- dataset[sample(nrow(dataset), size = round(((nrow(dataset)) * 80)/100), replace = TRUE), ]
    
    for(k in 1:nrow(st_bootstrap)){
      st_bootstrap$occurences[k] <- length(which((subsample$from_state == st_bootstrap$from_state[k]) &
                                                   (subsample$to_state == st_bootstrap$to_state[k])))
    }
    
    
    matrix_bootstrap_norm <- norm(matrix(data = as.numeric(st_bootstrap$occurences), byrow = T, ncol = 4))
    row.names(matrix_bootstrap_norm) <- c(all_state_transitions)
    colnames(matrix_bootstrap_norm) <- c(all_state_transitions)
    
    if(j == 1){
      df_bootstrap_norm <- as.data.frame(as.table(matrix_bootstrap_norm))  
      colnames(df_bootstrap_norm) <- c("from_state", "to_state", paste(c(project, j), collapse = "_"))
    } else {
      temp <- as.data.frame(as.table(matrix_bootstrap_norm))
      df_bootstrap_norm <- cbind(df_bootstrap_norm, temp$Freq)
      colnames(df_bootstrap_norm)[colnames(df_bootstrap_norm) == "Freq"] <- paste(c(project, j), collapse = "_")
    }
    
    print(num_repetitions)
    num_repetitions <- num_repetitions - 1
  }
  
  df_bootstrap_norm[df_bootstrap_norm == 0.0] <- NA
  for(j in 1:nrow(df_bootstrap_norm)){
    row1[1, ] <- c(project = as.character(project),
                   from_state = as.character(df_bootstrap_norm[j, 1]),
                   to_state = as.character(df_bootstrap_norm[j, 2]),
                   low_quantile = quantile(as.numeric(df_bootstrap_norm[j, 3:10002]), c(0.05, 0.95), na.rm = TRUE)[[1]][1], 
                   high_quantile = quantile(as.numeric(df_bootstrap_norm[j, 3:10002]), c(0.05, 0.95), na.rm = TRUE)[[2]][1],
                   bootstrap_mean = mean(as.numeric(df_bootstrap_norm[j, 3:10002]), na.rm = TRUE))
    bootstrap_mean <- rbind(bootstrap_mean, row1)
  }
  write.csv(bootstrap_mean[bootstrap_mean$project == project, ], paste(c("study2/rq3/random_", as.character(project), ".csv"), collapse = ""))
}

#PERCENTAGE OF FILES ALWAYS READABLE, ALWAYS UNREDABLE OR BOTH READABLE AND UNREDABLE
percentages <- subset(newTransitionOrdered, select = c(project, filename))
percentages <- percentages[!duplicated(percentages), ]

percentages$only_readable <- 0
percentages$only_unreadable <- 0
percentages$readable_or_unreadable <- 0
n <- nrow(percentages)
for(i in 1:nrow(percentages)){
  print(n)
  n <- n - 1
  temp <- newTransitionOrdered[((newTransitionOrdered$project == percentages$project[i]) & (newTransitionOrdered$filename == percentages$filename[i])), ]
  #print(percentages$project[i])
  #print(percentages$filename[i])
  
  only_readable <- 0
  only_unreadable <- 0
  r_o_u <- 0
  for(j in 1:nrow(temp)){
    if((temp$from_state[j] == "created") || (temp$from_state[j] == "renamed")){
      if(temp$to_state[j] == "readable"){
        only_readable <- only_readable + 1
      } else {
        if(temp$to_state[j] == "unreadable"){
          only_unreadable <- only_unreadable + 1
        }
      }
    } else {
      if((temp$from_state[j] == "readable") && (temp$to_state[j] == "readable")){
        only_readable <- only_readable + 1
      } else {
        if((temp$from_state[j] == "unreadable") && (temp$to_state[j] == "unreadable")){
          only_unreadable <- only_unreadable + 1
        } else {
          if(((temp$from_state[j] == "readable") && (temp$to_state[j] == "unreadable")) ||
             ((temp$from_state[j] == "unreadable") && (temp$to_state[j] == "readable"))){
            r_o_u <- r_o_u + 1
          } 
        }
      }
    }
  }
  # print(only_readable)
  # print(only_unreadable)
  # print(r_o_u)
  if(r_o_u != 0){
    percentages$only_readable[i] <- 0
    percentages$only_unreadable[i] <- 0
    percentages$readable_or_unreadable[i] <- 1
  } else {
    if((only_readable > only_unreadable) && (r_o_u == 0)){
      percentages$only_readable[i] <- 1  
      percentages$only_unreadable[i] <- 0
      percentages$readable_or_unreadable[i] <- 0
    } else {
      if((only_unreadable > only_readable) && (r_o_u == 0)){
        percentages$only_readable[i] <- 0  
        percentages$only_unreadable[i] <- 1
        percentages$readable_or_unreadable[i] <- 0
      }
    }
  }
}

mean(percentages$only_readable)
#[1] 0.8786418
mean(percentages$only_unreadable)
#[1] 0.110466
mean(percentages$readable_or_unreadable)
#[1] 0.01086285
mean(percentages$only_readable) + mean(percentages$only_unreadable) + mean(percentages$readable_or_unreadable)
sum(percentages$only_readable) + sum(percentages$only_unreadable) + sum(percentages$readable_or_unreadable)

for(project in unique(percentages$project)){
  temp <- percentages[percentages$project == project, ]
  print(project)
  print(mean(temp$only_readable))
  print(mean(temp$only_unreadable))
  print(mean(temp$readable_or_unreadable))
  print(mean(temp$only_readable) + mean(temp$only_unreadable) + mean(temp$readable_or_unreadable))
}



