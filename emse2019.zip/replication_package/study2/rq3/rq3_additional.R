library(effsize)
library(robustbase)

readability_additional <- read.csv("study2/rq3/rq3_additional.csv")

readability_r_u <- readability_additional[readability_additional$from_state == "readable" & readability_additional$to_state == "unreadable", ]
readability_u_r <- readability_additional[readability_additional$from_state == "unreadable" & readability_additional$to_state == "readable", ]

#Filter all files with at least one transition from unreadable to unreadable or from unreadable to readable
readability_filtered <- rbind(readability_r_u, readability_u_r)
readability_new_filtered <- readability_filtered
files <- unique(readability_filtered$filename)
for(i in 1:length(files)){
  print(i)
  dataset <- readability_additional[readability_additional$filename == files[i], ]
  if(i == 1){
    readability_new_filtered <- dataset
  } else {
    readability_new_filtered <- rbind(readability_new_filtered, dataset)
  }
}

readability_filtered_r_u <- readability_new_filtered[readability_new_filtered$from_state == "readable" & readability_new_filtered$to_state == "unreadable", ]
nrow(readability_filtered_r_u)
readability_filtered_u_r <- readability_new_filtered[readability_new_filtered$from_state == "unreadable" & readability_new_filtered$to_state == "readable", ]
nrow(readability_filtered_u_r)
readability_filtered_u_u <- readability_new_filtered[readability_new_filtered$from_state == "unreadable" & readability_new_filtered$to_state == "unreadable", ]
nrow(readability_filtered_u_u)
readability_filtered_r_r <- readability_new_filtered[readability_new_filtered$from_state == "readable" & readability_new_filtered$to_state == "readable", ]
nrow(readability_filtered_r_r)
readability_filtered_same_state <- rbind(readability_filtered_u_u, readability_filtered_r_r)
nrow(readability_filtered_same_state)

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u$files_changed, readability_filtered_u_r$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u$files_changed, readability_filtered_u_r$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u$files_changed, readability_filtered_same_state$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u$files_changed, readability_filtered_same_state$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r$files_changed, readability_filtered_same_state$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r$files_changed, readability_filtered_same_state$files_changed)

p.adjust(c(0.3082, 0.03969, 0.0004087), method="BH")

summary(readability_filtered_r_u$files_changed)
summary(readability_filtered_u_r$files_changed)
summary(readability_filtered_same_state$files_changed)

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u$line_changed, readability_filtered_u_r$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u$line_changed, readability_filtered_u_r$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u$line_changed, readability_filtered_same_state$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u$line_changed, readability_filtered_same_state$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r$line_changed, readability_filtered_same_state$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r$line_changed, readability_filtered_same_state$line_changed)

p.adjust(c(0.1532, 2.2e-16, 2.2e-16), method="BH")

summary(readability_filtered_r_u$line_changed)
summary(readability_filtered_u_r$line_changed)
summary(readability_filtered_same_state$line_changed)

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u$line_added, readability_filtered_u_r$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u$line_added, readability_filtered_u_r$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u$line_added, readability_filtered_same_state$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u$line_added, readability_filtered_same_state$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r$line_added, readability_filtered_same_state$line_added, alternative = "two.sided")
#p-value < 2.2e-16
cliff.delta(readability_filtered_u_r$line_added, readability_filtered_same_state$line_added)
#0.4781378 (large)

p.adjust(c(0.01683, 2.2e-16, 2.2e-16), method="BH")

summary(readability_filtered_r_u$line_added)
summary(readability_filtered_u_r$line_added)
summary(readability_filtered_same_state$line_added)

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u$line_removed, readability_filtered_u_r$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u$line_removed, readability_filtered_u_r$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u$line_removed, readability_filtered_same_state$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u$line_removed, readability_filtered_same_state$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r$line_removed, readability_filtered_same_state$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r$line_removed, readability_filtered_same_state$line_removed)

p.adjust(c(0.8427, 2.2e-16, 2.2e-16), method="BH")

summary(readability_filtered_r_u$line_removed)
summary(readability_filtered_u_r$line_removed)
summary(readability_filtered_same_state$line_removed)

par(mfrow = c(2,2))
adjbox(readability_filtered_r_u$files_changed, readability_filtered_u_r$files_changed, readability_filtered_same_state$files_changed, outline = FALSE, main="Files changed", names = c("R+", "R-", "R0"))
adjbox(readability_filtered_r_u$line_changed, readability_filtered_u_r$line_changed, readability_filtered_same_state$line_changed, outline = FALSE, main="Lines changed", names = c("R+", "R-", "R0")) 
adjbox(readability_filtered_r_u$line_added, readability_filtered_u_r$line_added, readability_filtered_same_state$line_added, outline = FALSE, main="Lines added", names = c("R+", "R-", "R0"))
adjbox(readability_filtered_r_u$line_removed, readability_filtered_u_r$line_removed, readability_filtered_same_state$line_removed, outline = FALSE, main="Lines removed", names = c("R+", "R-", "R0"))

################APACHE BEAM
readability_filtered_r_u_apache_beam <- readability_filtered_r_u[readability_filtered_r_u$project == "apache-beam", ]
readability_filtered_u_r_apache_beam <- readability_filtered_u_r[readability_filtered_u_r$project == "apache-beam", ]
readability_filtered_same_state_apache_beam <- readability_filtered_same_state[readability_filtered_same_state$project == "apache-beam", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_beam$files_changed, readability_filtered_u_r_apache_beam$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_beam$files_changed, readability_filtered_u_r_apache_beam$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_beam$files_changed, readability_filtered_same_state_apache_beam$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_beam$files_changed, readability_filtered_same_state_apache_beam$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_beam$files_changed, readability_filtered_same_state_apache_beam$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_beam$files_changed, readability_filtered_same_state_apache_beam$files_changed)

p.adjust(c(0.1484, 0.07, 7.023e-05), method="BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_beam$line_changed, readability_filtered_u_r_apache_beam$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_beam$line_changed, readability_filtered_u_r_apache_beam$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_beam$line_changed, readability_filtered_same_state_apache_beam$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_beam$line_changed, readability_filtered_same_state_apache_beam$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_beam$line_changed, readability_filtered_same_state_apache_beam$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_beam$line_changed, readability_filtered_same_state_apache_beam$line_changed)

p.adjust(c(0.02334, 0.0008573, 1.9995e-07), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_beam$line_added, readability_filtered_u_r_apache_beam$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_beam$line_added, readability_filtered_u_r_apache_beam$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_beam$line_added, readability_filtered_same_state_apache_beam$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_beam$line_added, readability_filtered_same_state_apache_beam$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_beam$line_added, readability_filtered_same_state_apache_beam$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_beam$line_added, readability_filtered_same_state_apache_beam$line_added)

p.adjust(c(0.02334, 0.0008573, 1.9995e-07), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_beam$line_removed, readability_filtered_u_r_apache_beam$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_beam$line_removed, readability_filtered_u_r_apache_beam$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_beam$line_removed, readability_filtered_same_state_apache_beam$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_beam$line_removed, readability_filtered_same_state_apache_beam$line_removed)
#0.5149961 (large)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_beam$line_removed, readability_filtered_same_state_apache_beam$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_beam$line_removed, readability_filtered_same_state_apache_beam$line_removed)

p.adjust(c(0.4508, 7.665e-06, 0.00314), method = "BH")

#APACHE CXF
readability_filtered_r_u_apache_cxf <- readability_filtered_r_u[readability_filtered_r_u$project == "apache-cxf", ]
readability_filtered_u_r_apache_cxf <- readability_filtered_u_r[readability_filtered_u_r$project == "apache-cxf", ]
readability_filtered_same_state_apache_cxf <- readability_filtered_same_state[readability_filtered_same_state$project == "apache-cxf", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_cxf$files_changed, readability_filtered_u_r_apache_cxf$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_cxf$files_changed, readability_filtered_u_r_apache_cxf$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_cxf$files_changed, readability_filtered_same_state_apache_cxf$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_cxf$files_changed, readability_filtered_same_state_apache_cxf$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_cxf$files_changed, readability_filtered_same_state_apache_cxf$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_cxf$files_changed, readability_filtered_same_state_apache_cxf$files_changed)

p.adjust(c(0.4858, 0.2431, 0.02397), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_cxf$line_changed, readability_filtered_u_r_apache_cxf$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_cxf$line_changed, readability_filtered_u_r_apache_cxf$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_cxf$line_changed, readability_filtered_same_state_apache_cxf$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_cxf$line_changed, readability_filtered_same_state_apache_cxf$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_cxf$line_changed, readability_filtered_same_state_apache_cxf$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_cxf$line_changed, readability_filtered_same_state_apache_cxf$line_changed)

p.adjust(c(0.1697, 3.099e-06, 8.734e-15), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_cxf$line_added, readability_filtered_u_r_apache_cxf$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_cxf$line_added, readability_filtered_u_r_apache_cxf$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_cxf$line_added, readability_filtered_same_state_apache_cxf$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_cxf$line_added, readability_filtered_same_state_apache_cxf$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_cxf$line_added, readability_filtered_same_state_apache_cxf$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_cxf$line_added, readability_filtered_same_state_apache_cxf$line_added)

p.adjust(c(0.9099, 1.321e-05, 9.986e-10), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_cxf$line_removed, readability_filtered_u_r_apache_cxf$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_cxf$line_removed, readability_filtered_u_r_apache_cxf$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_cxf$line_removed, readability_filtered_same_state_apache_cxf$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_cxf$line_removed, readability_filtered_same_state_apache_cxf$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_cxf$line_removed, readability_filtered_same_state_apache_cxf$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_cxf$line_removed, readability_filtered_same_state_apache_cxf$line_removed)

p.adjust(c(0.01776, 0.3415, 2.275e-06), method = "BH")

#APACHE DELTASPIKE
readability_filtered_r_u_apache_deltaspike <- readability_filtered_r_u[readability_filtered_r_u$project == "apache-deltaspike", ]
readability_filtered_u_r_apache_deltaspike <- readability_filtered_u_r[readability_filtered_u_r$project == "apache-deltaspike", ]
readability_filtered_same_state_apache_deltaspike<- readability_filtered_same_state[readability_filtered_same_state$project == "apache-deltaspike", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_deltaspike$files_changed, readability_filtered_u_r_apache_deltaspike$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_deltaspike$files_changed, readability_filtered_u_r_apache_deltaspike$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_deltaspike$files_changed, readability_filtered_same_state_apache_deltaspike$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_deltaspike$files_changed, readability_filtered_same_state_apache_deltaspike$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_deltaspike$files_changed, readability_filtered_same_state_apache_deltaspike$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_deltaspike$files_changed, readability_filtered_same_state_apache_deltaspike$files_changed)

p.adjust(c(0.8117, 0.8706, 0.5814), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_deltaspike$line_changed, readability_filtered_u_r_apache_deltaspike$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_deltaspike$line_changed, readability_filtered_u_r_apache_deltaspike$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_deltaspike$line_changed, readability_filtered_same_state_apache_deltaspike$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_deltaspike$line_changed, readability_filtered_same_state_apache_deltaspike$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_deltaspike$line_changed, readability_filtered_same_state_apache_deltaspike$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_deltaspike$line_changed, readability_filtered_same_state_apache_deltaspike$line_changed)

p.adjust(c(1, 0.0006198, 0.001151), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_deltaspike$line_added, readability_filtered_u_r_apache_deltaspike$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_deltaspike$line_added, readability_filtered_u_r_apache_deltaspike$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_deltaspike$line_added, readability_filtered_same_state_apache_deltaspike$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_deltaspike$line_added, readability_filtered_same_state_apache_deltaspike$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_deltaspike$line_added, readability_filtered_same_state_apache_deltaspike$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_deltaspike$line_added, readability_filtered_same_state_apache_deltaspike$line_added)

p.adjust(c(0.607, 0.0025, 0.00169), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_deltaspike$line_removed, readability_filtered_u_r_apache_deltaspike$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_deltaspike$line_removed, readability_filtered_u_r_apache_deltaspike$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_deltaspike$line_removed, readability_filtered_same_state_apache_deltaspike$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_deltaspike$line_removed, readability_filtered_same_state_apache_deltaspike$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_deltaspike$line_removed, readability_filtered_same_state_apache_deltaspike$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_deltaspike$line_removed, readability_filtered_same_state_apache_deltaspike$line_removed)

p.adjust(c(0.7673, 0.001007, 0.05323), method = "BH")

#APACHE FALCON
readability_filtered_r_u_apache_falcon <- readability_filtered_r_u[readability_filtered_r_u$project == "apache-falcon", ]
readability_filtered_u_r_apache_falcon <- readability_filtered_u_r[readability_filtered_u_r$project == "apache-falcon", ]
readability_filtered_same_state_apache_falcon<- readability_filtered_same_state[readability_filtered_same_state$project == "apache-falcon", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_falcon$files_changed, readability_filtered_u_r_apache_falcon$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_falcon$files_changed, readability_filtered_u_r_apache_falcon$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_falcon$files_changed, readability_filtered_same_state_apache_falcon$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_falcon$files_changed, readability_filtered_same_state_apache_falcon$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_falcon$files_changed, readability_filtered_same_state_apache_falcon$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_falcon$files_changed, readability_filtered_same_state_apache_falcon$files_changed)

p.adjust(c(0.8834, 0.2764, 0.2586), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_falcon$line_changed, readability_filtered_u_r_apache_falcon$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_falcon$line_changed, readability_filtered_u_r_apache_falcon$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_falcon$line_changed, readability_filtered_same_state_apache_falcon$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_falcon$line_changed, readability_filtered_same_state_apache_falcon$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_falcon$line_changed, readability_filtered_same_state_apache_falcon$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_falcon$line_changed, readability_filtered_same_state_apache_falcon$line_changed)

p.adjust(c(0.3336, 0.002005, 0.1052), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_falcon$line_added, readability_filtered_u_r_apache_falcon$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_falcon$line_added, readability_filtered_u_r_apache_falcon$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_falcon$line_added, readability_filtered_same_state_apache_falcon$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_falcon$line_added, readability_filtered_same_state_apache_falcon$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_falcon$line_added, readability_filtered_same_state_apache_falcon$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_falcon$line_added, readability_filtered_same_state_apache_falcon$line_added)

p.adjust(c(0.5183, 0.1693, 0.5833), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_falcon$line_removed, readability_filtered_u_r_apache_falcon$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_falcon$line_removed, readability_filtered_u_r_apache_falcon$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_falcon$line_removed, readability_filtered_same_state_apache_falcon$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_falcon$line_removed, readability_filtered_same_state_apache_falcon$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_falcon$line_removed, readability_filtered_same_state_apache_falcon$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_falcon$line_removed, readability_filtered_same_state_apache_falcon$line_removed)

p.adjust(c(0.3043, 0.03043, 0.643), method = "BH")

#APACHE FLINK
readability_filtered_r_u_apache_flink <- readability_filtered_r_u[readability_filtered_r_u$project == "apache-flink", ]
readability_filtered_u_r_apache_flink <- readability_filtered_u_r[readability_filtered_u_r$project == "apache-flink", ]
readability_filtered_same_state_apache_flink<- readability_filtered_same_state[readability_filtered_same_state$project == "apache-flink", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_flink$files_changed, readability_filtered_u_r_apache_flink$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_flink$files_changed, readability_filtered_u_r_apache_flink$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_flink$files_changed, readability_filtered_same_state_apache_flink$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_flink$files_changed, readability_filtered_same_state_apache_flink$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_flink$files_changed, readability_filtered_same_state_apache_flink$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_flink$files_changed, readability_filtered_same_state_apache_flink$files_changed)

p.adjust(c(0.008386, 0.3436, 0.003567), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_flink$line_changed, readability_filtered_u_r_apache_flink$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_flink$line_changed, readability_filtered_u_r_apache_flink$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_flink$line_changed, readability_filtered_same_state_apache_flink$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_flink$line_changed, readability_filtered_same_state_apache_flink$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_flink$line_changed, readability_filtered_same_state_apache_flink$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_flink$line_changed, readability_filtered_same_state_apache_flink$line_changed)

p.adjust(c(0.4761, 7.027e-09, 5.783e-11), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_flink$line_added, readability_filtered_u_r_apache_flink$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_flink$line_added, readability_filtered_u_r_apache_flink$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_flink$line_added, readability_filtered_same_state_apache_flink$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_flink$line_added, readability_filtered_same_state_apache_flink$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_flink$line_added, readability_filtered_same_state_apache_flink$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_flink$line_added, readability_filtered_same_state_apache_flink$line_added)

p.adjust(c(0.1831, 2.047e-05, 8.856e-10), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_flink$line_removed, readability_filtered_u_r_apache_flink$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_flink$line_removed, readability_filtered_u_r_apache_flink$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_flink$line_removed, readability_filtered_same_state_apache_flink$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_flink$line_removed, readability_filtered_same_state_apache_flink$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_flink$line_removed, readability_filtered_same_state_apache_flink$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_flink$line_removed, readability_filtered_same_state_apache_flink$line_removed)

p.adjust(c(0.3382, 8.311e-09, 0.0001556), method = "BH")

#APACHE HADOOP
readability_filtered_r_u_apache_hadoop <- readability_filtered_r_u[readability_filtered_r_u$project == "apache-hadoop", ]
readability_filtered_u_r_apache_hadoop <- readability_filtered_u_r[readability_filtered_u_r$project == "apache-hadoop", ]
readability_filtered_same_state_apache_hadoop<- readability_filtered_same_state[readability_filtered_same_state$project == "apache-hadoop", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_hadoop$files_changed, readability_filtered_u_r_apache_hadoop$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_hadoop$files_changed, readability_filtered_u_r_apache_hadoop$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_hadoop$files_changed, readability_filtered_same_state_apache_hadoop$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_hadoop$files_changed, readability_filtered_same_state_apache_hadoop$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_hadoop$files_changed, readability_filtered_same_state_apache_hadoop$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_hadoop$files_changed, readability_filtered_same_state_apache_hadoop$files_changed)

p.adjust(c(0.479, 0.01262, 0.02238), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_hadoop$line_changed, readability_filtered_u_r_apache_hadoop$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_hadoop$line_changed, readability_filtered_u_r_apache_hadoop$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_hadoop$line_changed, readability_filtered_same_state_apache_hadoop$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_hadoop$line_changed, readability_filtered_same_state_apache_hadoop$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_hadoop$line_changed, readability_filtered_same_state_apache_hadoop$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_hadoop$line_changed, readability_filtered_same_state_apache_hadoop$line_changed)

p.adjust(c(0.2993, 0.001105, 1.741e-06), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_hadoop$line_added, readability_filtered_u_r_apache_hadoop$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_hadoop$line_added, readability_filtered_u_r_apache_hadoop$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_hadoop$line_added, readability_filtered_same_state_apache_hadoop$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_hadoop$line_added, readability_filtered_same_state_apache_hadoop$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_hadoop$line_added, readability_filtered_same_state_apache_hadoop$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_hadoop$line_added, readability_filtered_same_state_apache_hadoop$line_added)

p.adjust(c(0.7878, 0.0007665, 1.069e-05), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_hadoop$line_removed, readability_filtered_u_r_apache_hadoop$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_hadoop$line_removed, readability_filtered_u_r_apache_hadoop$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_hadoop$line_removed, readability_filtered_same_state_apache_hadoop$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_hadoop$line_removed, readability_filtered_same_state_apache_hadoop$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_hadoop$line_removed, readability_filtered_same_state_apache_hadoop$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_hadoop$line_removed, readability_filtered_same_state_apache_hadoop$line_removed)

p.adjust(c(0.07412, 0.8295, 0.01912), method = "BH")

#APACHE INCUBATOR SKYWALKING
readability_filtered_r_u_apache_incubator_skywalking <- readability_filtered_r_u[readability_filtered_r_u$project == "apache-incubator-skywalking", ]
readability_filtered_u_r_apache_incubator_skywalking <- readability_filtered_u_r[readability_filtered_u_r$project == "apache-incubator-skywalking", ]
readability_filtered_same_state_apache_incubator_skywalking <- readability_filtered_same_state[readability_filtered_same_state$project == "apache-incubator-skywalking", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_incubator_skywalking$files_changed, readability_filtered_u_r_apache_incubator_skywalking$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_incubator_skywalking$files_changed, readability_filtered_u_r_apache_incubator_skywalking$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_incubator_skywalking$files_changed, readability_filtered_same_state_apache_incubator_skywalking$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_incubator_skywalking$files_changed, readability_filtered_same_state_apache_incubator_skywalking$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_incubator_skywalking$files_changed, readability_filtered_same_state_apache_incubator_skywalking$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_incubator_skywalking$files_changed, readability_filtered_same_state_apache_incubator_skywalking$files_changed)

p.adjust(c(0.1899, 0.0004201, 0.0961), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_incubator_skywalking$line_changed, readability_filtered_u_r_apache_incubator_skywalking$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_incubator_skywalking$line_changed, readability_filtered_u_r_apache_incubator_skywalking$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_incubator_skywalking$line_changed, readability_filtered_same_state_apache_incubator_skywalking$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_incubator_skywalking$line_changed, readability_filtered_same_state_apache_incubator_skywalking$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_incubator_skywalking$line_changed, readability_filtered_same_state_apache_incubator_skywalking$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_incubator_skywalking$line_changed, readability_filtered_same_state_apache_incubator_skywalking$line_changed)

p.adjust(c(0.7449, 1.735e-09, 1.372e-05), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_incubator_skywalking$line_added, readability_filtered_r_u_apache_incubator_skywalking$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_incubator_skywalking$line_added, readability_filtered_r_u_apache_incubator_skywalking$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_incubator_skywalking$line_added, readability_filtered_same_state_apache_incubator_skywalking$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_incubator_skywalking$line_added, readability_filtered_same_state_apache_incubator_skywalking$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_incubator_skywalking$line_added, readability_filtered_same_state_apache_incubator_skywalking$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_incubator_skywalking$line_added, readability_filtered_same_state_apache_incubator_skywalking$line_added)

p.adjust(c(1, 1.948e-09, 0.0009764), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_incubator_skywalking$line_removed, readability_filtered_r_u_apache_incubator_skywalking$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_incubator_skywalking$line_removed, readability_filtered_r_u_apache_incubator_skywalking$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_incubator_skywalking$line_removed, readability_filtered_same_state_apache_incubator_skywalking$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_incubator_skywalking$line_removed, readability_filtered_same_state_apache_incubator_skywalking$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_incubator_skywalking$line_removed, readability_filtered_same_state_apache_incubator_skywalking$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_incubator_skywalking$line_removed, readability_filtered_same_state_apache_incubator_skywalking$line_removed)

p.adjust(c(1, 0.0003166, 7.269e-05), method = "BH")

#APACHE ISIS
readability_filtered_r_u_apache_isis <- readability_filtered_r_u[readability_filtered_r_u$project == "apache-isis", ]
readability_filtered_u_r_apache_isis <- readability_filtered_u_r[readability_filtered_u_r$project == "apache-isis", ]
readability_filtered_same_state_apache_isis <- readability_filtered_same_state[readability_filtered_same_state$project == "apache-isis", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_isis$files_changed, readability_filtered_u_r_apache_isis$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_isis$files_changed, readability_filtered_u_r_apache_isis$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_isis$files_changed, readability_filtered_same_state_apache_isis$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_isis$files_changed, readability_filtered_same_state_apache_isis$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_isis$files_changed, readability_filtered_same_state_apache_isis$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_isis$files_changed, readability_filtered_same_state_apache_isis$files_changed)

p.adjust(c(0.04995, 0.8833, 0.1598), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_isis$line_changed, readability_filtered_u_r_apache_isis$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_isis$line_changed, readability_filtered_u_r_apache_isis$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_isis$line_changed, readability_filtered_same_state_apache_isis$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_isis$line_changed, readability_filtered_same_state_apache_isis$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_isis$line_changed, readability_filtered_same_state_apache_isis$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_isis$line_changed, readability_filtered_same_state_apache_isis$line_changed)

p.adjust(c(0.01333, 9.822e-07, 0.000148), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_isis$line_added, readability_filtered_u_r_apache_isis$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_isis$line_added, readability_filtered_u_r_apache_isis$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_isis$line_added, readability_filtered_same_state_apache_isis$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_isis$line_added, readability_filtered_same_state_apache_isis$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_isis$line_added, readability_filtered_same_state_apache_isis$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_isis$line_added, readability_filtered_same_state_apache_isis$line_added)

p.adjust(c(0.3097, 0.005055, 0.0008863), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_isis$line_removed, readability_filtered_u_r_apache_isis$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_isis$line_removed, readability_filtered_u_r_apache_isis$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_isis$line_removed, readability_filtered_same_state_apache_isis$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_isis$line_removed, readability_filtered_same_state_apache_isis$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_isis$line_removed, readability_filtered_same_state_apache_isis$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_isis$line_removed, readability_filtered_same_state_apache_isis$line_removed)

p.adjust(c(0.008645, 2.648e-06, 0.003923), method = "BH")

#APACHE QPID-BROKER-J
readability_filtered_r_u_apache_qpid_broker_j <- readability_filtered_r_u[readability_filtered_r_u$project == "apache-qpid-broker-j", ]
readability_filtered_u_r_apache_qpid_broker_j <- readability_filtered_u_r[readability_filtered_u_r$project == "apache-qpid-broker-j", ]
readability_filtered_same_state_apache_qpid_broker_j <- readability_filtered_same_state[readability_filtered_same_state$project == "apache-qpid-broker-j", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_qpid_broker_j$files_changed, readability_filtered_u_r_apache_qpid_broker_j$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid_broker_j$files_changed, readability_filtered_u_r_apache_qpid_broker_j$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_qpid_broker_j$files_changed, readability_filtered_same_state_apache_qpid_broker_j$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid_broker_j$files_changed, readability_filtered_same_state_apache_qpid_broker_j$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_qpid_broker_j$files_changed, readability_filtered_same_state_apache_qpid_broker_j$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_qpid_broker_j$files_changed, readability_filtered_same_state_apache_qpid_broker_j$files_changed)

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_qpid_broker_j$line_changed, readability_filtered_u_r_apache_qpid_broker_j$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid_broker_j$line_changed, readability_filtered_u_r_apache_qpid_broker_j$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_qpid_broker_j$line_changed, readability_filtered_same_state_apache_qpid_broker_j$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid_broker_j$line_changed, readability_filtered_same_state_apache_qpid_broker_j$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_qpid_broker_j$line_changed, readability_filtered_same_state_apache_qpid_broker_j$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_qpid_broker_j$line_changed, readability_filtered_same_state_apache_qpid_broker_j$line_changed)

p.adjust(c(0.427, 2.001e-08, 1.478e-10), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_qpid_broker_j$line_added, readability_filtered_u_r_apache_qpid_broker_j$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid_broker_j$line_added, readability_filtered_u_r_apache_qpid_broker_j$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_qpid_broker_j$line_added, readability_filtered_same_state_apache_qpid_broker_j$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid_broker_j$line_added, readability_filtered_same_state_apache_qpid_broker_j$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_qpid_broker_j$line_added, readability_filtered_same_state_apache_qpid_broker_j$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_qpid_broker_j$line_added, readability_filtered_same_state_apache_qpid_broker_j$line_added)

p.adjust(c(0.02834, 0.01692, 1.12e-09), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_qpid_broker_j$line_removed, readability_filtered_u_r_apache_qpid_broker_j$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid_broker_j$line_removed, readability_filtered_u_r_apache_qpid_broker_j$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_qpid_broker_j$line_removed, readability_filtered_same_state_apache_qpid_broker_j$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid_broker_j$line_removed, readability_filtered_same_state_apache_qpid_broker_j$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_qpid_broker_j$line_removed, readability_filtered_same_state_apache_qpid_broker_j$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_qpid_broker_j$line_removed, readability_filtered_same_state_apache_qpid_broker_j$line_removed)

p.adjust(c(0.2724, 3.55e-07, 0.0001622), method = "BH")

#APACHE QPID
readability_filtered_r_u_apache_qpid <- readability_filtered_r_u[readability_filtered_r_u$project == "apache-qpid", ]
readability_filtered_u_r_apache_qpid <- readability_filtered_u_r[readability_filtered_u_r$project == "apache-qpid", ]
readability_filtered_same_state_apache_qpid <- readability_filtered_same_state[readability_filtered_same_state$project == "apache-qpid", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_qpid$files_changed, readability_filtered_u_r_apache_qpid$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid$files_changed, readability_filtered_u_r_apache_qpid$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_qpid$files_changed, readability_filtered_same_state_apache_qpid$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid$files_changed, readability_filtered_same_state_apache_qpid$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_qpid$files_changed, readability_filtered_same_state_apache_qpid$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_qpid$files_changed, readability_filtered_same_state_apache_qpid$files_changed)

p.adjust(c(0.2996, 0.1888, 0.9712), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_qpid$line_changed, readability_filtered_u_r_apache_qpid$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid$line_changed, readability_filtered_u_r_apache_qpid$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_qpid$line_changed, readability_filtered_same_state_apache_qpid$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid$line_changed, readability_filtered_same_state_apache_qpid$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_qpid$line_changed, readability_filtered_same_state_apache_qpid$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_qpid$line_changed, readability_filtered_same_state_apache_qpid$line_changed)

p.adjust(c(0.2743, 0.1554, 5.561e-05), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_qpid$line_added, readability_filtered_u_r_apache_qpid$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid$line_added, readability_filtered_u_r_apache_qpid$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_qpid$line_added, readability_filtered_same_state_apache_qpid$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid$line_added, readability_filtered_same_state_apache_qpid$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_qpid$line_added, readability_filtered_same_state_apache_qpid$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_qpid$line_added, readability_filtered_same_state_apache_qpid$line_added)

p.adjust(c(0.4462, 0.03502, 2.695e-05), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_qpid$line_removed, readability_filtered_u_r_apache_qpid$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid$line_removed, readability_filtered_u_r_apache_qpid$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_qpid$line_removed, readability_filtered_same_state_apache_qpid$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_qpid$line_removed, readability_filtered_same_state_apache_qpid$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_qpid$line_removed, readability_filtered_same_state_apache_qpid$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_qpid$line_removed, readability_filtered_same_state_apache_qpid$line_removed)

p.adjust(c(0.3244, 0.7982, 0.04011), method = "BH")

#APACHE TOMCAT
readability_filtered_r_u_apache_tomcat <- readability_filtered_r_u[readability_filtered_r_u$project == "apache-tomcat", ]
readability_filtered_u_r_apache_tomcat <- readability_filtered_u_r[readability_filtered_u_r$project == "apache-tomcat", ]
readability_filtered_same_state_apache_tomcat <- readability_filtered_same_state[readability_filtered_same_state$project == "apache-tomcat", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_tomcat$files_changed, readability_filtered_u_r_apache_tomcat$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_tomcat$files_changed, readability_filtered_u_r_apache_tomcat$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_tomcat$files_changed, readability_filtered_same_state_apache_tomcat$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_tomcat$files_changed, readability_filtered_same_state_apache_tomcat$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_tomcat$files_changed, readability_filtered_same_state_apache_tomcat$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_tomcat$files_changed, readability_filtered_same_state_apache_tomcat$files_changed)

p.adjust(c(0.8802, 0.5186, 0.2925), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_tomcat$line_changed, readability_filtered_u_r_apache_tomcat$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_tomcat$line_changed, readability_filtered_u_r_apache_tomcat$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_tomcat$line_changed, readability_filtered_same_state_apache_tomcat$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_tomcat$line_changed, readability_filtered_same_state_apache_tomcat$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_tomcat$line_changed, readability_filtered_same_state_apache_tomcat$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_tomcat$line_changed, readability_filtered_same_state_apache_tomcat$line_changed)

p.adjust(c(0.2545, 5.615e-06, 1.253e-08), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_tomcat$line_added, readability_filtered_u_r_apache_tomcat$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_tomcat$line_added, readability_filtered_u_r_apache_tomcat$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_tomcat$line_added, readability_filtered_same_state_apache_tomcat$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_tomcat$line_added, readability_filtered_same_state_apache_tomcat$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_tomcat$line_added, readability_filtered_same_state_apache_tomcat$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_tomcat$line_added, readability_filtered_same_state_apache_tomcat$line_added)

p.adjust(c(0.01231, 0.113, 2.844e-07), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_apache_tomcat$line_removed, readability_filtered_u_r_apache_tomcat$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_tomcat$line_removed, readability_filtered_u_r_apache_tomcat$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_apache_tomcat$line_removed, readability_filtered_same_state_apache_tomcat$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_apache_tomcat$line_removed, readability_filtered_same_state_apache_tomcat$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_apache_tomcat$line_removed, readability_filtered_same_state_apache_tomcat$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_apache_tomcat$line_removed, readability_filtered_same_state_apache_tomcat$line_removed)

p.adjust(c(0.3254, 7.677e-06, 0.00112), method = "BH")

#fullcontact-fullcontact4j
readability_filtered_r_u_fullcontact_fullcontact4j <- readability_filtered_r_u[readability_filtered_r_u$project == "fullcontact-fullcontact4j", ]
readability_filtered_u_r_fullcontact_fullcontact4j <- readability_filtered_u_r[readability_filtered_u_r$project == "fullcontact-fullcontact4j", ]
readability_filtered_same_state_fullcontact_fullcontact4j <- readability_filtered_same_state[readability_filtered_same_state$project == "fullcontact-fullcontact4j", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_fullcontact_fullcontact4j$files_changed, readability_filtered_u_r_fullcontact_fullcontact4j$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_fullcontact_fullcontact4j$files_changed, readability_filtered_u_r_fullcontact_fullcontact4j$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_fullcontact_fullcontact4j$files_changed, readability_filtered_same_state_fullcontact_fullcontact4j$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_fullcontact_fullcontact4j$files_changed, readability_filtered_same_state_fullcontact_fullcontact4j$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_fullcontact_fullcontact4j$files_changed, readability_filtered_same_state_fullcontact_fullcontact4j$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_fullcontact_fullcontact4j$files_changed, readability_filtered_same_state_fullcontact_fullcontact4j$files_changed)

#summary(readability_filtered_r_u$files_changed)
#summary(readability_filtered_u_r$files_changed)
#summary(readability_filtered_same_state$files_changed)
#adjbox(readability_filtered_r_u$files_changed, readability_filtered_u_r$files_changed, readability_filtered_same_state$files_changed)
#adjbox(readability_filtered_r_u$files_changed, readability_filtered_u_r$files_changed, readability_filtered_same_state$files_changed, outline = FALSE)

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_fullcontact_fullcontact4j$line_changed, readability_filtered_u_r_fullcontact_fullcontact4j$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_fullcontact_fullcontact4j$line_changed, readability_filtered_u_r_fullcontact_fullcontact4j$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_fullcontact_fullcontact4j$line_changed, readability_filtered_same_state_fullcontact_fullcontact4j$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_fullcontact_fullcontact4j$line_changed, readability_filtered_same_state_fullcontact_fullcontact4j$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_fullcontact_fullcontact4j$line_changed, readability_filtered_same_state_fullcontact_fullcontact4j$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_fullcontact_fullcontact4j$line_changed, readability_filtered_same_state_fullcontact_fullcontact4j$line_changed, alternative = "two.sided")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_fullcontact_fullcontact4j$line_added, readability_filtered_u_r_fullcontact_fullcontact4j$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_fullcontact_fullcontact4j$line_added, readability_filtered_u_r_fullcontact_fullcontact4j$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_fullcontact_fullcontact4j$line_added, readability_filtered_same_state_fullcontact_fullcontact4j$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_fullcontact_fullcontact4j$line_added, readability_filtered_same_state_fullcontact_fullcontact4j$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_fullcontact_fullcontact4j$line_added, readability_filtered_same_state_fullcontact_fullcontact4j$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_fullcontact_fullcontact4j$line_added, readability_filtered_same_state_fullcontact_fullcontact4j$line_added)

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_fullcontact_fullcontact4j$line_removed, readability_filtered_u_r_fullcontact_fullcontact4j$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_fullcontact_fullcontact4j$line_removed, readability_filtered_u_r_fullcontact_fullcontact4j$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_fullcontact_fullcontact4j$line_removed, readability_filtered_same_state_fullcontact_fullcontact4j$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_fullcontact_fullcontact4j$line_removed, readability_filtered_same_state_fullcontact_fullcontact4j$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_fullcontact_fullcontact4j$line_removed, readability_filtered_same_state_fullcontact_fullcontact4j$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_fullcontact_fullcontact4j$line_removed, readability_filtered_same_state_fullcontact_fullcontact4j$line_removed, alternative = "two.sided")

#cms-sw-hlt-confdb
readability_filtered_r_u_cms_sw_hlt_confdb <- readability_filtered_r_u[readability_filtered_r_u$project == "cms-sw-hlt-confdb", ]
readability_filtered_u_r_cms_sw_hlt_confdb <- readability_filtered_u_r[readability_filtered_u_r$project == "cms-sw-hlt-confdb", ]
readability_filtered_same_state_cms_sw_hlt_confdb <- readability_filtered_same_state[readability_filtered_same_state$project == "cms-sw-hlt-confdb", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_cms_sw_hlt_confdb$files_changed, readability_filtered_u_r_cms_sw_hlt_confdb$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_cms_sw_hlt_confdb$files_changed, readability_filtered_u_r_cms_sw_hlt_confdb$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_cms_sw_hlt_confdb$files_changed, readability_filtered_same_state_cms_sw_hlt_confdb$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_cms_sw_hlt_confdb$files_changed, readability_filtered_same_state_cms_sw_hlt_confdb$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_cms_sw_hlt_confdb$files_changed, readability_filtered_same_state_cms_sw_hlt_confdb$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_cms_sw_hlt_confdb$files_changed, readability_filtered_same_state_cms_sw_hlt_confdb$files_changed, alternative = "two.sided")

p.adjust(c(0.3613, 0.6176, 1), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_cms_sw_hlt_confdb$line_changed, readability_filtered_u_r_cms_sw_hlt_confdb$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_cms_sw_hlt_confdb$line_changed, readability_filtered_u_r_cms_sw_hlt_confdb$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_cms_sw_hlt_confdb$line_changed, readability_filtered_same_state_cms_sw_hlt_confdb$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_cms_sw_hlt_confdb$line_changed, readability_filtered_same_state_cms_sw_hlt_confdb$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_cms_sw_hlt_confdb$line_changed, readability_filtered_same_state_cms_sw_hlt_confdb$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_cms_sw_hlt_confdb$line_changed, readability_filtered_same_state_cms_sw_hlt_confdb$line_changed)

p.adjust(c(0.8571, 0.09353, 0.01627), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_cms_sw_hlt_confdb$line_added, readability_filtered_u_r_cms_sw_hlt_confdb$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_cms_sw_hlt_confdb$line_added, readability_filtered_u_r_cms_sw_hlt_confdb$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_cms_sw_hlt_confdb$line_added, readability_filtered_same_state_cms_sw_hlt_confdb$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_cms_sw_hlt_confdb$line_added, readability_filtered_same_state_cms_sw_hlt_confdb$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_cms_sw_hlt_confdb$line_added, readability_filtered_same_state_cms_sw_hlt_confdb$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_cms_sw_hlt_confdb$line_added, readability_filtered_same_state_cms_sw_hlt_confdb$line_added)

p.adjust(c(0.3115, 0.07916, 0.05632), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_cms_sw_hlt_confdb$line_removed, readability_filtered_u_r_cms_sw_hlt_confdb$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_cms_sw_hlt_confdb$line_removed, readability_filtered_u_r_cms_sw_hlt_confdb$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_cms_sw_hlt_confdb$line_removed, readability_filtered_same_state_cms_sw_hlt_confdb$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_cms_sw_hlt_confdb$line_removed, readability_filtered_same_state_cms_sw_hlt_confdb$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_cms_sw_hlt_confdb$line_removed, readability_filtered_same_state_cms_sw_hlt_confdb$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_cms_sw_hlt_confdb$line_removed, readability_filtered_same_state_cms_sw_hlt_confdb$line_removed)

p.adjust(c(0.4018, 0.2306, 0.01286), method = "BH")

#CHENOPODIUM IGV
readability_filtered_r_u_chenopodium_IGV <- readability_filtered_r_u[readability_filtered_r_u$project == "chenopodium-IGV", ]
readability_filtered_u_r_chenopodium_IGV <- readability_filtered_u_r[readability_filtered_u_r$project == "chenopodium-IGV", ]
readability_filtered_same_state_chenopodium_IGV <- readability_filtered_same_state[readability_filtered_same_state$project == "chenopodium-IGV", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_chenopodium_IGV$files_changed, readability_filtered_u_r_chenopodium_IGV$files_changed, alternative = "two.sided")
#p-value 0.8618
cliff.delta(readability_filtered_r_u_chenopodium_IGV$files_changed, readability_filtered_u_r_chenopodium_IGV$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_chenopodium_IGV$files_changed, readability_filtered_same_state_chenopodium_IGV$files_changed, alternative = "two.sided")
#p-value 0.5327
cliff.delta(readability_filtered_r_u_chenopodium_IGV$files_changed, readability_filtered_same_state_chenopodium_IGV$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_chenopodium_IGV$files_changed, readability_filtered_same_state_chenopodium_IGV$files_changed, alternative = "two.sided")
#p-value 0.4287
cliff.delta(readability_filtered_u_r_chenopodium_IGV$files_changed, readability_filtered_same_state_chenopodium_IGV$files_changed)

p.adjust(c(0.8618, 0.5327, 0.4287), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_chenopodium_IGV$line_changed, readability_filtered_u_r_chenopodium_IGV$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_chenopodium_IGV$line_changed, readability_filtered_u_r_chenopodium_IGV$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_chenopodium_IGV$line_changed, readability_filtered_same_state_chenopodium_IGV$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_chenopodium_IGV$line_changed, readability_filtered_same_state_chenopodium_IGV$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_chenopodium_IGV$line_changed, readability_filtered_same_state_chenopodium_IGV$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_chenopodium_IGV$line_changed, readability_filtered_same_state_chenopodium_IGV$line_changed)

p.adjust(c(0.2364, 0.001837, 3.559e-05), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_chenopodium_IGV$line_added, readability_filtered_u_r_chenopodium_IGV$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_chenopodium_IGV$line_added, readability_filtered_u_r_chenopodium_IGV$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_chenopodium_IGV$line_added, readability_filtered_same_state_chenopodium_IGV$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_chenopodium_IGV$line_added, readability_filtered_same_state_chenopodium_IGV$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_chenopodium_IGV$line_added, readability_filtered_same_state_chenopodium_IGV$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_chenopodium_IGV$line_added, readability_filtered_same_state_chenopodium_IGV$line_added)

p.adjust(c(0.04294, 0.06, 4.385e-05), method = "BH")

#summary(readability_filtered_r_u$line_added)
#summary(readability_filtered_u_r$line_added)
#summary(readability_filtered_same_state$line_added)
#adjbox(readability_filtered_r_u$line_added, readability_filtered_u_r$line_added, readability_filtered_same_state$line_added)
#adjbox(readability_filtered_r_u$line_added, readability_filtered_u_r$line_added, readability_filtered_same_state$line_added, outline = FALSE)

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_chenopodium_IGV$line_removed, readability_filtered_u_r_chenopodium_IGV$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_chenopodium_IGV$line_removed, readability_filtered_u_r_chenopodium_IGV$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_chenopodium_IGV$line_removed, readability_filtered_same_state_chenopodium_IGV$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_chenopodium_IGV$line_removed, readability_filtered_same_state_chenopodium_IGV$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_chenopodium_IGV$line_removed, readability_filtered_same_state_chenopodium_IGV$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_chenopodium_IGV$line_removed, readability_filtered_same_state_chenopodium_IGV$line_removed)

p.adjust(c(0.6643, 0.0002434, 0.02183), method = "BH")

#jboss-modules-jboss-modules
readability_filtered_r_u_jboss_modules_jboss_modules <- readability_filtered_r_u[readability_filtered_r_u$project == "jboss-modules-jboss-modules", ]
readability_filtered_u_r_jboss_modules_jboss_modules <- readability_filtered_u_r[readability_filtered_u_r$project == "jboss-modules-jboss-modules", ]
readability_filtered_same_state_jboss_modules_jboss_modules <- readability_filtered_same_state[readability_filtered_same_state$project == "jboss-modules-jboss-modules", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_jboss_modules_jboss_modules$files_changed, readability_filtered_u_r_jboss_modules_jboss_modules$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jboss_modules_jboss_modules$files_changed, readability_filtered_u_r_jboss_modules_jboss_modules$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_jboss_modules_jboss_modules$files_changed, readability_filtered_same_state_jboss_modules_jboss_modules$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jboss_modules_jboss_modules$files_changed, readability_filtered_same_state_jboss_modules_jboss_modules$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_jboss_modules_jboss_modules$files_changed, readability_filtered_same_state_jboss_modules_jboss_modules$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_jboss_modules_jboss_modules$files_changed, readability_filtered_same_state_jboss_modules_jboss_modules$files_changed)

p.adjust(c(0.6667, 0.7095, 0.1202), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_jboss_modules_jboss_modules$line_changed, readability_filtered_u_r_jboss_modules_jboss_modules$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jboss_modules_jboss_modules$line_changed, readability_filtered_u_r_jboss_modules_jboss_modules$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_jboss_modules_jboss_modules$line_changed, readability_filtered_same_state_jboss_modules_jboss_modules$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jboss_modules_jboss_modules$line_changed, readability_filtered_same_state_jboss_modules_jboss_modules$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_jboss_modules_jboss_modules$line_changed, readability_filtered_same_state_jboss_modules_jboss_modules$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_jboss_modules_jboss_modules$line_changed, readability_filtered_same_state_jboss_modules_jboss_modules$line_changed)

p.adjust(c(1, 0.1041, 0.02138), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_jboss_modules_jboss_modules$line_added, readability_filtered_u_r_jboss_modules_jboss_modules$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jboss_modules_jboss_modules$line_added, readability_filtered_u_r_jboss_modules_jboss_modules$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_jboss_modules_jboss_modules$line_added, readability_filtered_same_state_jboss_modules_jboss_modules$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jboss_modules_jboss_modules$line_added, readability_filtered_same_state_jboss_modules_jboss_modules$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_jboss_modules_jboss_modules$line_added, readability_filtered_same_state_jboss_modules_jboss_modules$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_jboss_modules_jboss_modules$line_added, readability_filtered_same_state_jboss_modules_jboss_modules$line_added)

p.adjust(c(1, 0.1017, 0.02058), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_jboss_modules_jboss_modules$line_removed, readability_filtered_u_r_jboss_modules_jboss_modules$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jboss_modules_jboss_modules$line_removed, readability_filtered_u_r_jboss_modules_jboss_modules$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_jboss_modules_jboss_modules$line_removed, readability_filtered_same_state_jboss_modules_jboss_modules$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jboss_modules_jboss_modules$line_removed, readability_filtered_same_state_jboss_modules_jboss_modules$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_jboss_modules_jboss_modules$line_removed, readability_filtered_same_state_jboss_modules_jboss_modules$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_jboss_modules_jboss_modules$line_removed, readability_filtered_same_state_jboss_modules_jboss_modules$line_removed)

p.adjust(c(1, 0.3824, 0.828), method = "BH")

#jbosstools-jbosstools-jbpm
readability_filtered_r_u_jbosstools_jbosstools_jbpm <- readability_filtered_r_u[readability_filtered_r_u$project == "jbosstools-jbosstools-jbpm", ]
readability_filtered_u_r_jbosstools_jbosstools_jbpm <- readability_filtered_u_r[readability_filtered_u_r$project == "jbosstools-jbosstools-jbpm", ]
readability_filtered_same_state_jbosstools_jbosstools_jbpm <- readability_filtered_same_state[readability_filtered_same_state$project == "jbosstools-jbosstools-jbpm", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_jbosstools_jbosstools_jbpm$files_changed, readability_filtered_u_r_jbosstools_jbosstools_jbpm$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jbosstools_jbosstools_jbpm$files_changed, readability_filtered_u_r_jbosstools_jbosstools_jbpm$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_jbosstools_jbosstools_jbpm$files_changed, readability_filtered_same_state_jbosstools_jbosstools_jbpm$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jbosstools_jbosstools_jbpm$files_changed, readability_filtered_same_state_jbosstools_jbosstools_jbpm$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_jbosstools_jbosstools_jbpm$files_changed, readability_filtered_same_state_jbosstools_jbosstools_jbpm$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_jbosstools_jbosstools_jbpm$files_changed, readability_filtered_same_state_jbosstools_jbosstools_jbpm$files_changed)

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_jbosstools_jbosstools_jbpm$line_changed, readability_filtered_u_r_jbosstools_jbosstools_jbpm$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jbosstools_jbosstools_jbpm$line_changed, readability_filtered_u_r_jbosstools_jbosstools_jbpm$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_jbosstools_jbosstools_jbpm$line_changed, readability_filtered_same_state_jbosstools_jbosstools_jbpm$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jbosstools_jbosstools_jbpm$line_changed, readability_filtered_same_state_jbosstools_jbosstools_jbpm$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_jbosstools_jbosstools_jbpm$line_changed, readability_filtered_same_state_jbosstools_jbosstools_jbpm$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_jbosstools_jbosstools_jbpm$line_changed, readability_filtered_same_state_jbosstools_jbosstools_jbpm$line_changed)

p.adjust(c(0.001414), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_jbosstools_jbosstools_jbpm$line_added, readability_filtered_u_r_jbosstools_jbosstools_jbpm$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jbosstools_jbosstools_jbpm$line_added, readability_filtered_u_r_jbosstools_jbosstools_jbpm$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_jbosstools_jbosstools_jbpm$line_added, readability_filtered_same_state_jbosstools_jbosstools_jbpm$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jbosstools_jbosstools_jbpm$line_added, readability_filtered_same_state_jbosstools_jbosstools_jbpm$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_jbosstools_jbosstools_jbpm$line_added, readability_filtered_same_state_jbosstools_jbosstools_jbpm$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_jbosstools_jbosstools_jbpm$line_added, readability_filtered_same_state_jbosstools_jbosstools_jbpm$line_added)

p.adjust(c(0.006123), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_jbosstools_jbosstools_jbpm$line_removed, readability_filtered_u_r_jbosstools_jbosstools_jbpm$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jbosstools_jbosstools_jbpm$line_removed, readability_filtered_u_r_jbosstools_jbosstools_jbpm$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_jbosstools_jbosstools_jbpm$line_removed, readability_filtered_same_state_jbosstools_jbosstools_jbpm$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_jbosstools_jbosstools_jbpm$line_removed, readability_filtered_same_state_jbosstools_jbosstools_jbpm$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_jbosstools_jbosstools_jbpm$line_removed, readability_filtered_same_state_jbosstools_jbosstools_jbpm$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_jbosstools_jbosstools_jbpm$line_removed, readability_filtered_same_state_jbosstools_jbosstools_jbpm$line_removed)

p.adjust(c(0.01687), method = "BH")

#niths-niths
readability_filtered_r_u_niths_niths <- readability_filtered_r_u[readability_filtered_r_u$project == "niths-niths", ]
readability_filtered_u_r_niths_niths <- readability_filtered_u_r[readability_filtered_u_r$project == "niths-niths", ]
readability_filtered_same_state_niths_niths <- readability_filtered_same_state[readability_filtered_same_state$project == "niths-niths", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_niths_niths$files_changed, readability_filtered_u_r_niths_niths$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_niths_niths$files_changed, readability_filtered_u_r_niths_niths$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_niths_niths$files_changed, readability_filtered_same_state_niths_niths$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_niths_niths$files_changed, readability_filtered_same_state_niths_niths$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_niths_niths$files_changed, readability_filtered_same_state_niths_niths$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_niths_niths$files_changed, readability_filtered_same_state_niths_niths$files_changed)

p.adjust(c(0.4678, 0.1163, 0.07957), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_niths_niths$line_changed, readability_filtered_u_r_niths_niths$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_niths_niths$line_changed, readability_filtered_u_r_niths_niths$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_niths_niths$line_changed, readability_filtered_same_state_niths_niths$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_niths_niths$line_changed, readability_filtered_same_state_niths_niths$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_niths_niths$line_changed, readability_filtered_same_state_niths_niths$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_niths_niths$line_changed, readability_filtered_same_state_niths_niths$line_changed)

p.adjust(c(0.5614, 0.2601, 0.05071), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_niths_niths$line_added, readability_filtered_u_r_niths_niths$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_niths_niths$line_added, readability_filtered_u_r_niths_niths$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_niths_niths$line_added, readability_filtered_same_state_niths_niths$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_niths_niths$line_added, readability_filtered_same_state_niths_niths$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_niths_niths$line_added, readability_filtered_same_state_niths_niths$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_niths_niths$line_added, readability_filtered_same_state_niths_niths$line_added)

p.adjust(c(0.4857, 0.4167, 0.05658), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_niths_niths$line_removed, readability_filtered_u_r_niths_niths$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_niths_niths$line_removed, readability_filtered_u_r_niths_niths$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_niths_niths$line_removed, readability_filtered_same_state_niths_niths$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_niths_niths$line_removed, readability_filtered_same_state_niths_niths$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_niths_niths$line_removed, readability_filtered_same_state_niths_niths$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_niths_niths$line_removed, readability_filtered_same_state_niths_niths$line_removed)

p.adjust(c(0.8817, 0.8804, 0.5918), method = "BH")

#nuxeo-archives-nuxeo-runtime
readability_filtered_r_u_nuxeo_archives_nuxeo_runtime <- readability_filtered_r_u[readability_filtered_r_u$project == "nuxeo-archives-nuxeo-runtime", ]
readability_filtered_u_r_nuxeo_archives_nuxeo_runtime <- readability_filtered_u_r[readability_filtered_u_r$project == "nuxeo-archives-nuxeo-runtime", ]
readability_filtered_same_state_nuxeo_archives_nuxeo_runtime <- readability_filtered_same_state[readability_filtered_same_state$project == "nuxeo-archives-nuxeo-runtime", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$files_changed, readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$files_changed, alternative = "two.sided")
#p-value 0.3333
cliff.delta(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$files_changed, readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$files_changed)
#1 (large)

#R+ vs R0
wilcox.test(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$files_changed, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$files_changed, alternative = "two.sided")
#p-value 0.3401
cliff.delta(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$files_changed, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$files_changed, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$files_changed, alternative = "two.sided")
#p-value 0.06725
cliff.delta(readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$files_changed, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$files_changed)

p.adjust(c(0.3333, 0.3401, 0.06725), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$line_changed, readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$line_changed, readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$line_changed, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$line_changed, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$line_changed, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$line_changed, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$line_changed)

p.adjust(c(0.6667, 0.07782, 0.5204), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$line_added, readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$line_added, readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$line_added, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$line_added, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$line_added, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$line_added, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$line_added)

p.adjust(c(0.3333, 0.04363, 0.4656), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$line_removed, readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$line_removed, readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$line_removed, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_nuxeo_archives_nuxeo_runtime$line_removed, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$line_removed, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_nuxeo_archives_nuxeo_runtime$line_removed, readability_filtered_same_state_nuxeo_archives_nuxeo_runtime$line_removed)

p.adjust(c(1, 0.2578, 0.4179), method = "BH")

#openengsb-openengsb
readability_filtered_r_u_openengsb_openengsb <- readability_filtered_r_u[readability_filtered_r_u$project == "openengsb-openengsb", ]
readability_filtered_u_r_openengsb_openengsb <- readability_filtered_u_r[readability_filtered_u_r$project == "openengsb-openengsb", ]
readability_filtered_same_state_openengsb_openengsb <- readability_filtered_same_state[readability_filtered_same_state$project == "openengsb-openengsb", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_openengsb_openengsb$files_changed, readability_filtered_u_r_openengsb_openengsb$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_openengsb_openengsb$files_changed, readability_filtered_u_r_openengsb_openengsb$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_openengsb_openengsb$files_changed, readability_filtered_same_state_openengsb_openengsb$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_openengsb_openengsb$files_changed, readability_filtered_same_state_openengsb_openengsb$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_openengsb_openengsb$files_changed, readability_filtered_same_state_openengsb_openengsb$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_openengsb_openengsb$files_changed, readability_filtered_same_state_openengsb_openengsb$files_changed, alternative = "two.sided")

p.adjust(c(0.01967, 0.0001195, 0.01653), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_openengsb_openengsb$line_changed, readability_filtered_u_r_openengsb_openengsb$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_openengsb_openengsb$line_changed, readability_filtered_u_r_openengsb_openengsb$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_openengsb_openengsb$line_changed, readability_filtered_same_state_openengsb_openengsb$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_openengsb_openengsb$line_changed, readability_filtered_same_state_openengsb_openengsb$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_openengsb_openengsb$line_changed, readability_filtered_same_state_openengsb_openengsb$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_openengsb_openengsb$line_changed, readability_filtered_same_state_openengsb_openengsb$line_changed)

p.adjust(c(0.2707, 1.438e-05, 0.00561), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_openengsb_openengsb$line_added, readability_filtered_u_r_openengsb_openengsb$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_openengsb_openengsb$line_added, readability_filtered_u_r_openengsb_openengsb$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_openengsb_openengsb$line_added, readability_filtered_same_state_openengsb_openengsb$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_openengsb_openengsb$line_added, readability_filtered_same_state_openengsb_openengsb$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_openengsb_openengsb$line_added, readability_filtered_same_state_openengsb_openengsb$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_openengsb_openengsb$line_added, readability_filtered_same_state_openengsb_openengsb$line_added)

p.adjust(c(0.2157, 5.887e-05, 0.002448), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_openengsb_openengsb$line_removed, readability_filtered_u_r_openengsb_openengsb$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_openengsb_openengsb$line_removed, readability_filtered_u_r_openengsb_openengsb$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_openengsb_openengsb$line_removed, readability_filtered_same_state_openengsb_openengsb$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_openengsb_openengsb$line_removed, readability_filtered_same_state_openengsb_openengsb$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_openengsb_openengsb$line_removed, readability_filtered_same_state_openengsb_openengsb$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_openengsb_openengsb$line_removed, readability_filtered_same_state_openengsb_openengsb$line_removed)

p.adjust(c(1, 0.1885, 0.1434), method = "BH")

#linkedin-parseq
readability_filtered_r_u_linkedin_parseq <- readability_filtered_r_u[readability_filtered_r_u$project == "linkedin-parseq", ]
readability_filtered_u_r_linkedin_parseq <- readability_filtered_u_r[readability_filtered_u_r$project == "linkedin-parseq", ]
readability_filtered_same_state_linkedin_parseq <- readability_filtered_same_state[readability_filtered_same_state$project == "linkedin-parseq", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_linkedin_parseq$files_changed, readability_filtered_u_r_linkedin_parseq$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_linkedin_parseq$files_changed, readability_filtered_u_r_linkedin_parseq$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_linkedin_parseq$files_changed, readability_filtered_same_state_linkedin_parseq$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_linkedin_parseq$files_changed, readability_filtered_same_state_linkedin_parseq$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_linkedin_parseq$files_changed, readability_filtered_same_state_linkedin_parseq$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_linkedin_parseq$files_changed, readability_filtered_same_state_linkedin_parseq$files_changed)

p.adjust(c(0.8452, 0.02378, 0.1792), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_linkedin_parseq$line_changed, readability_filtered_u_r_linkedin_parseq$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_linkedin_parseq$line_changed, readability_filtered_u_r_linkedin_parseq$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_linkedin_parseq$line_changed, readability_filtered_same_state_linkedin_parseq$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_linkedin_parseq$line_changed, readability_filtered_same_state_linkedin_parseq$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_linkedin_parseq$line_changed, readability_filtered_same_state_linkedin_parseq$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_linkedin_parseq$line_changed, readability_filtered_same_state_linkedin_parseq$line_changed)

p.adjust(c(0.6667, 0.01463, 0.1408), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_linkedin_parseq$line_added, readability_filtered_u_r_linkedin_parseq$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_linkedin_parseq$line_added, readability_filtered_u_r_linkedin_parseq$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_linkedin_parseq$line_added, readability_filtered_same_state_linkedin_parseq$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_linkedin_parseq$line_added, readability_filtered_same_state_linkedin_parseq$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_linkedin_parseq$line_added, readability_filtered_same_state_linkedin_parseq$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_linkedin_parseq$line_added, readability_filtered_same_state_linkedin_parseq$line_added)

p.adjust(c(0.6667, 0.0199, 0.1282), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_linkedin_parseq$line_removed, readability_filtered_u_r_linkedin_parseq$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_linkedin_parseq$line_removed, readability_filtered_u_r_linkedin_parseq$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_linkedin_parseq$line_removed, readability_filtered_same_state_linkedin_parseq$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_linkedin_parseq$line_removed, readability_filtered_same_state_linkedin_parseq$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_linkedin_parseq$line_removed, readability_filtered_same_state_linkedin_parseq$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_linkedin_parseq$line_removed, readability_filtered_same_state_linkedin_parseq$line_removed)

p.adjust(c(0.4444, 0.09396, 0.1172), method = "BH")

#ReactiveX-RxJava
readability_filtered_r_u_ReactiveX_RxJava <- readability_filtered_r_u[readability_filtered_r_u$project == "ReactiveX-RxJava", ]
readability_filtered_u_r_ReactiveX_RxJava <- readability_filtered_u_r[readability_filtered_u_r$project == "ReactiveX-RxJava", ]
readability_filtered_same_state_ReactiveX_RxJava <- readability_filtered_same_state[readability_filtered_same_state$project == "ReactiveX-RxJava", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_ReactiveX_RxJava$files_changed, readability_filtered_u_r_ReactiveX_RxJava$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_ReactiveX_RxJava$files_changed, readability_filtered_u_r_ReactiveX_RxJava$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_ReactiveX_RxJava$files_changed, readability_filtered_same_state_ReactiveX_RxJava$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_ReactiveX_RxJava$files_changed, readability_filtered_same_state_ReactiveX_RxJava$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_ReactiveX_RxJava$files_changed, readability_filtered_same_state_ReactiveX_RxJava$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_ReactiveX_RxJava$files_changed, readability_filtered_same_state_ReactiveX_RxJava$files_changed)

p.adjust(c(0.8606, 0.3799, 0.09122), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_ReactiveX_RxJava$line_changed, readability_filtered_u_r_ReactiveX_RxJava$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_ReactiveX_RxJava$line_changed, readability_filtered_u_r_ReactiveX_RxJava$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_ReactiveX_RxJava$line_changed, readability_filtered_same_state_ReactiveX_RxJava$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_ReactiveX_RxJava$line_changed, readability_filtered_same_state_ReactiveX_RxJava$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_ReactiveX_RxJava$line_changed, readability_filtered_same_state_ReactiveX_RxJava$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_ReactiveX_RxJava$line_changed, readability_filtered_same_state_ReactiveX_RxJava$line_changed)

p.adjust(c(0.9072, 0.01196, 0.0002323), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_ReactiveX_RxJava$line_added, readability_filtered_u_r_ReactiveX_RxJava$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_ReactiveX_RxJava$line_added, readability_filtered_u_r_ReactiveX_RxJava$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_ReactiveX_RxJava$line_added, readability_filtered_same_state_ReactiveX_RxJava$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_ReactiveX_RxJava$line_added, readability_filtered_same_state_ReactiveX_RxJava$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_ReactiveX_RxJava$line_added, readability_filtered_same_state_ReactiveX_RxJava$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_ReactiveX_RxJava$line_added, readability_filtered_same_state_ReactiveX_RxJava$line_added)

p.adjust(c(0.2439, 0.3795, 0.0004591), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_ReactiveX_RxJava$line_removed, readability_filtered_u_r_ReactiveX_RxJava$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_ReactiveX_RxJava$line_removed, readability_filtered_u_r_ReactiveX_RxJava$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_ReactiveX_RxJava$line_removed, readability_filtered_same_state_ReactiveX_RxJava$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_ReactiveX_RxJava$line_removed, readability_filtered_same_state_ReactiveX_RxJava$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_ReactiveX_RxJava$line_removed, readability_filtered_same_state_ReactiveX_RxJava$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_ReactiveX_RxJava$line_removed, readability_filtered_same_state_ReactiveX_RxJava$line_removed)

p.adjust(c(0.3213, 0.02107, 0.08058), method = "BH")

#SIB-Colombia-sib-dataportal
readability_filtered_r_u_SIB_Colombia_sib_dataportal <- readability_filtered_r_u[readability_filtered_r_u$project == "SIB-Colombia-sib-dataportal", ]
readability_filtered_u_r_SIB_Colombia_sib_dataportal <- readability_filtered_u_r[readability_filtered_u_r$project == "SIB-Colombia-sib-dataportal", ]
readability_filtered_same_state_SIB_Colombia_sib_dataportal <- readability_filtered_same_state[readability_filtered_same_state$project == "SIB-Colombia-sib-dataportal", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_SIB_Colombia_sib_dataportal$files_changed, readability_filtered_u_r_SIB_Colombia_sib_dataportal$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_SIB_Colombia_sib_dataportal$files_changed, readability_filtered_u_r_SIB_Colombia_sib_dataportal$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_SIB_Colombia_sib_dataportal$files_changed, readability_filtered_same_state_SIB_Colombia_sib_dataportal$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_SIB_Colombia_sib_dataportal$files_changed, readability_filtered_same_state_SIB_Colombia_sib_dataportal$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_SIB_Colombia_sib_dataportal$files_changed, readability_filtered_same_state_SIB_Colombia_sib_dataportal$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_SIB_Colombia_sib_dataportal$files_changed, readability_filtered_same_state_SIB_Colombia_sib_dataportal$files_changed)

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_SIB_Colombia_sib_dataportal$line_changed, readability_filtered_u_r_SIB_Colombia_sib_dataportal$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_SIB_Colombia_sib_dataportal$line_changed, readability_filtered_u_r_SIB_Colombia_sib_dataportal$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_SIB_Colombia_sib_dataportal$line_changed, readability_filtered_same_state_SIB_Colombia_sib_dataportal$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_SIB_Colombia_sib_dataportal$line_changed, readability_filtered_same_state_SIB_Colombia_sib_dataportal$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_SIB_Colombia_sib_dataportal$line_changed, readability_filtered_same_state_SIB_Colombia_sib_dataportal$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_SIB_Colombia_sib_dataportal$line_changed, readability_filtered_same_state_SIB_Colombia_sib_dataportal$line_changed)

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_SIB_Colombia_sib_dataportal$line_added, readability_filtered_u_r_SIB_Colombia_sib_dataportal$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_SIB_Colombia_sib_dataportal$line_added, readability_filtered_u_r_SIB_Colombia_sib_dataportal$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_SIB_Colombia_sib_dataportal$line_added, readability_filtered_same_state_SIB_Colombia_sib_dataportal$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_SIB_Colombia_sib_dataportal$line_added, readability_filtered_same_state_SIB_Colombia_sib_dataportal$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_SIB_Colombia_sib_dataportal$line_added, readability_filtered_same_state_SIB_Colombia_sib_dataportal$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_SIB_Colombia_sib_dataportal$line_added, readability_filtered_same_state_SIB_Colombia_sib_dataportal$line_added)

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_SIB_Colombia_sib_dataportal$line_removed, readability_filtered_u_r_SIB_Colombia_sib_dataportal$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_SIB_Colombia_sib_dataportal$line_removed, readability_filtered_u_r_SIB_Colombia_sib_dataportal$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_SIB_Colombia_sib_dataportal$line_removed, readability_filtered_same_state_SIB_Colombia_sib_dataportal$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_SIB_Colombia_sib_dataportal$line_removed, readability_filtered_same_state_SIB_Colombia_sib_dataportal$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_SIB_Colombia_sib_dataportal$line_removed, readability_filtered_same_state_SIB_Colombia_sib_dataportal$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_SIB_Colombia_sib_dataportal$line_removed, readability_filtered_same_state_SIB_Colombia_sib_dataportal$line_removed)

#undertow-io-undertow
readability_filtered_r_u_undertow_io_undertow <- readability_filtered_r_u[readability_filtered_r_u$project == "undertow-io-undertow", ]
readability_filtered_u_r_undertow_io_undertow <- readability_filtered_u_r[readability_filtered_u_r$project == "undertow-io-undertow", ]
readability_filtered_same_state_undertow_io_undertow <- readability_filtered_same_state[readability_filtered_same_state$project == "undertow-io-undertow", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_undertow_io_undertow$files_changed, readability_filtered_u_r_undertow_io_undertow$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_undertow_io_undertow$files_changed, readability_filtered_u_r_undertow_io_undertow$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_undertow_io_undertow$files_changed, readability_filtered_same_state_undertow_io_undertow$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_undertow_io_undertow$files_changed, readability_filtered_same_state_undertow_io_undertow$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_undertow_io_undertow$files_changed, readability_filtered_same_state_undertow_io_undertow$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_undertow_io_undertow$files_changed, readability_filtered_same_state_undertow_io_undertow$files_changed)

p.adjust(c(0.6134, 0.8866, 0.6272), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_undertow_io_undertow$line_changed, readability_filtered_u_r_undertow_io_undertow$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_undertow_io_undertow$line_changed, readability_filtered_u_r_undertow_io_undertow$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_undertow_io_undertow$line_changed, readability_filtered_same_state_undertow_io_undertow$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_undertow_io_undertow$line_changed, readability_filtered_same_state_undertow_io_undertow$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_undertow_io_undertow$line_changed, readability_filtered_same_state_undertow_io_undertow$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_undertow_io_undertow$line_changed, readability_filtered_same_state_undertow_io_undertow$line_changed)

p.adjust(c(0.6058, 1.358e-07, 6.032e-07), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_undertow_io_undertow$line_added, readability_filtered_u_r_undertow_io_undertow$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_undertow_io_undertow$line_added, readability_filtered_u_r_undertow_io_undertow$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_undertow_io_undertow$line_added, readability_filtered_same_state_undertow_io_undertow$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_undertow_io_undertow$line_added, readability_filtered_same_state_undertow_io_undertow$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_undertow_io_undertow$line_added, readability_filtered_same_state_undertow_io_undertow$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_undertow_io_undertow$line_added, readability_filtered_same_state_undertow_io_undertow$line_added)

p.adjust(c(0.3537, 0.0004617, 0.000197), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_undertow_io_undertow$line_removed, readability_filtered_u_r_undertow_io_undertow$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_undertow_io_undertow$line_removed, readability_filtered_u_r_undertow_io_undertow$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_undertow_io_undertow$line_removed, readability_filtered_same_state_undertow_io_undertow$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_undertow_io_undertow$line_removed, readability_filtered_same_state_undertow_io_undertow$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_undertow_io_undertow$line_removed, readability_filtered_same_state_undertow_io_undertow$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_undertow_io_undertow$line_removed, readability_filtered_same_state_undertow_io_undertow$line_removed)

p.adjust(c(0.3072, 2.38e-05, 0.02817), method = "BH")

#xnio-xnio
readability_filtered_r_u_xnio_xnio <- readability_filtered_r_u[readability_filtered_r_u$project == "xnio-xnio", ]
readability_filtered_u_r_xnio_xnio <- readability_filtered_u_r[readability_filtered_u_r$project == "xnio-xnio", ]
readability_filtered_same_state_xnio_xnio <- readability_filtered_same_state[readability_filtered_same_state$project == "xnio-xnio", ]

#FILES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_xnio_xnio$files_changed, readability_filtered_u_r_xnio_xnio$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_xnio_xnio$files_changed, readability_filtered_u_r_xnio_xnio$files_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_xnio_xnio$files_changed, readability_filtered_same_state_xnio_xnio$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_xnio_xnio$files_changed, readability_filtered_same_state_xnio_xnio$files_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_xnio_xnio$files_changed, readability_filtered_same_state_xnio_xnio$files_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_xnio_xnio$files_changed, readability_filtered_same_state_xnio_xnio$files_changed)

p.adjust(c(0.5684, 0.005961, 0.04476), method = "BH")

#LINES CHANGED
#R+ vs R-
wilcox.test(readability_filtered_r_u_xnio_xnio$line_changed, readability_filtered_u_r_xnio_xnio$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_xnio_xnio$line_changed, readability_filtered_u_r_xnio_xnio$line_changed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_xnio_xnio$line_changed, readability_filtered_same_state_xnio_xnio$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_xnio_xnio$line_changed, readability_filtered_same_state_xnio_xnio$line_changed)

#R- vs R0
wilcox.test(readability_filtered_u_r_xnio_xnio$line_changed, readability_filtered_same_state_xnio_xnio$line_changed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_xnio_xnio$line_changed, readability_filtered_same_state_xnio_xnio$line_changed)

p.adjust(c(0.6389, 0.001027, 0.009425), method = "BH")

#LINES ADDED
#R+ vs R-
wilcox.test(readability_filtered_r_u_xnio_xnio$line_added, readability_filtered_u_r_xnio_xnio$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_xnio_xnio$line_added, readability_filtered_u_r_xnio_xnio$line_added)

#R+ vs R0
wilcox.test(readability_filtered_r_u_xnio_xnio$line_added, readability_filtered_same_state_xnio_xnio$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_xnio_xnio$line_added, readability_filtered_same_state_xnio_xnio$line_added)

#R- vs R0
wilcox.test(readability_filtered_u_r_xnio_xnio$line_added, readability_filtered_same_state_xnio_xnio$line_added, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_xnio_xnio$line_added, readability_filtered_same_state_xnio_xnio$line_added)

p.adjust(c(0.4318, 0.0007845, 0.04374), method = "BH")

#LINES REMOVED
#R+ vs R-
wilcox.test(readability_filtered_r_u_xnio_xnio$line_removed, readability_filtered_u_r_xnio_xnio$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_xnio_xnio$line_removed, readability_filtered_u_r_xnio_xnio$line_removed)

#R+ vs R0
wilcox.test(readability_filtered_r_u_xnio_xnio$line_removed, readability_filtered_same_state_xnio_xnio$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_r_u_xnio_xnio$line_removed, readability_filtered_same_state_xnio_xnio$line_removed)

#R- vs R0
wilcox.test(readability_filtered_u_r_xnio_xnio$line_removed, readability_filtered_same_state_xnio_xnio$line_removed, alternative = "two.sided")
cliff.delta(readability_filtered_u_r_xnio_xnio$line_removed, readability_filtered_same_state_xnio_xnio$line_removed)

p.adjust(c(0.8701, 0.04778, 0.1175), method = "BH")