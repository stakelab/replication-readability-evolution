library(RColorBrewer)

survey <- read.csv("survey.csv", stringsAsFactors = FALSE)

######Demographic question
palette <- brewer.pal(7, "Blues")
par(mfrow=c(3, 2))
###Education
education <- table(survey$Education)
barplot(c(14, 36, 51, 21), col = palette[4:7], main = "Education", ylim = c(0,60), names.arg = c("High School Degree", "Bachelor's Degree", "Master's Degree", "PhD"), cex.main = 3, cex.names = 2, cex.axis = 2)

###Occupation
barplot(c(length(which(grepl("Student",survey$Occupation))), length(which(grepl("Working in industry",survey$Occupation))), length(which(grepl("Working in academia",survey$Occupation))), length(which(grepl("Open-source contributor",survey$Occupation)))), col = palette[4:7], main = "Occupation", ylim = c(0,70), names.arg = c("Student", "Working in industry", "Working in academia", "Open-source contributor"), cex.main = 3, cex.names = 2, cex.axis = 2)

###Programming experience
unique(survey$Programming_experience)
table(survey$Programming_experience)
barplot(table(survey$Programming_experience), col = palette[3:7], main = "Programming experience", ylim = c(0,70), cex.main = 3, cex.names = 2, cex.axis = 2)

###Programming languages
all_programming_languages <- unique(survey$Programming_languages)

#Remove ";"
first_clean_programming_languages <- c()
for(i in 1:length(all_programming_languages)){
  temp <- strsplit(all_programming_languages[i], ";")
  first_clean_programming_languages <- c(first_clean_programming_languages, temp[[1]])
}
unique(first_clean_programming_languages)

#Remove "and "
second_clean_programming_languages <- c()
for(i in 1:length(first_clean_programming_languages)){
  temp <- strsplit(first_clean_programming_languages[i], ", ")
  second_clean_programming_languages <- c(second_clean_programming_languages, temp[[1]])
}
unique(second_clean_programming_languages)

#Remove "and "
clean_programming_languages <- c()
for(i in 1:length(second_clean_programming_languages)){
  temp <- gsub("and ", "", second_clean_programming_languages[i])
  clean_programming_languages <- c(clean_programming_languages, temp[[1]])
}

clean_programming_languages
unique(clean_programming_languages)
table(clean_programming_languages)
ranking <- sort(table(clean_programming_languages), decreasing = TRUE)
barplot(c(38, 24, 17, 15, 13, 13, 10), col = palette[1:7], main = "Programming languages", ylim = c(0,40), names.arg = c("Java", "Python", "C++", "JavaScript/Typescript", "C", "PHP", "C#"), cex.main = 3, cex.names = 2, cex.axis = 2)

#Open source projects
survey$Open_source_projects[survey$Open_source_projects == ">= 10" ] <- ">=10"
table(survey$Open_source_projects)
barplot(c(56, 59, 7), col = palette[5:7], main = "Open source projects", ylim = c(0,60), names.arg = c("0", "1-5", "5 or more"), cex.main = 3, cex.names = 2, cex.axis = 2)

#Industrial projects
survey$Industrial_projects[survey$Industrial_projects == ">= 10" ] <- ">=10"
table(survey$Industrial_projects)
barplot(c(34, 54, 34), col = palette[5:7], main = "Industrial projects", ylim = c(0,60), names.arg = c("0", "1-5", "5 or more"), cex.main = 3, cex.names = 2, cex.axis = 2)

######Main question
palette <- brewer.pal(3, "Blues")
m <- matrix(c(1,2,3,4,4,4), nrow = 2, ncol = 3, byrow = TRUE)
layout(mat = m, heights = c(0.7,0.3))

deleted <- which(survey$Open_source_projects >= 1 | survey$Industrial_projects >= 1)
subsurvey_one_project <- survey[deleted,]
subsurvey_zero_project <- survey[-deleted,]

table(subsurvey_zero_project$Code_readability_in_writing_code)
table(subsurvey_one_project$Code_readability_in_writing_code)
code_readability_in_writing_code <- matrix(c(0, 2, 5, 7, 5, 1, 0, 13, 43, 46), ncol = 5, byrow = TRUE)
rownames(code_readability_in_writing_code) <- c("=0", ">=1")
colnames(code_readability_in_writing_code) <- c("Never", "Rarely", "Sometimes", "Often", "Always")
code_readability_in_writing_code <- as.table(code_readability_in_writing_code)
code_readability_in_writing_code
barplot(code_readability_in_writing_code, main = "\nQ1: When you write code, to what extent do you take\ninto account code readability?", col = palette[2:3], ylim = c(0,60), cex.main = 2.5, cex.names = 2, cex.axis = 2)

table(subsurvey_zero_project$Impact_of_the_change_on_code_readability)
table(subsurvey_one_project$Impact_of_the_change_on_code_readability)
table(survey$Impact_of_the_change_on_code_readability)
impact_of_the_change_on_code_readability <- matrix(c(0, 2, 6, 8, 3, 0, 3, 17, 48, 35), ncol = 5, byrow = TRUE)
rownames(impact_of_the_change_on_code_readability) <- c("=0", ">=1")
colnames(impact_of_the_change_on_code_readability) <- c("Never", "Rarely", "Sometimes", "Often", "Always")
impact_of_the_change_on_code_readability <- as.table(impact_of_the_change_on_code_readability)
impact_of_the_change_on_code_readability
barplot(impact_of_the_change_on_code_readability, main = "\nQ2: When reviewing code changes performed by your peers,\nto what extent do you consider the impact\nof the change on code readability?", col = palette[2:3], ylim = c(0,60), cex.main = 2.5, cex.names = 2, cex.axis = 2)

table(subsurvey_zero_project$Changes_to_improve_code_readability)
table(subsurvey_one_project$Changes_to_improve_code_readability)
table(survey$Changes_to_improve_code_readability)
changes_to_improve_code_readability <- matrix(c(0, 6, 2, 7, 4, 0, 8, 32, 42, 21), ncol = 5, byrow = TRUE)
rownames(changes_to_improve_code_readability) <- c("=0", ">=1")
colnames(changes_to_improve_code_readability) <- c("Never", "Rarely", "Sometimes", "Often", "Always")
changes_to_improve_code_readability <- as.table(changes_to_improve_code_readability)
changes_to_improve_code_readability
barplot(changes_to_improve_code_readability, main = "\nQ3: How often do you make changes\nto improve code readability?", col = palette[2:3], ylim = c(0,60), cex.main = 2.5, cex.names = 2, cex.axis = 2)

plot(1, type = "n", axes=FALSE, xlab="", ylab="")
legend("top", inset = 0, legend = my.table, col = palette[2:3], lty=15, lwd=20, cex = 2, horiz = TRUE, x.intersp = 0.01)

par(mfrow=c(1, 1))

table(subsurvey_zero_project$Frequence_of_a_big_change_in_code_readability)
table(subsurvey_one_project$Frequence_of_a_big_change_in_code_readability)
table(survey$Frequence_of_a_big_change_in_code_readability)
frequence_of_a_big_change_in_code_readability <- matrix(c(4, 7, 4, 4, 0, 5, 45, 30, 20, 3), ncol = 5, byrow = TRUE)
rownames(frequence_of_a_big_change_in_code_readability) <- c("==0", ">=1")
colnames(frequence_of_a_big_change_in_code_readability) <- c("Never", "Between 0% and 25%", "Between 25% and 50%", "Between 50% and 75%", "More than 75%")
frequence_of_a_big_change_in_code_readability <- as.table(frequence_of_a_big_change_in_code_readability)
frequence_of_a_big_change_in_code_readability
barplot(frequence_of_a_big_change_in_code_readability, main = "Q4: How frequently did you experience a big change in code readability (positive or negative) in the projects you worked on?", col = palette[2:3], ylim = c(0,60), cex.main = 2, cex.names = 2, cex.axis = 2)

#barplot(c(9, 52, 34, 24, 3), col = gray.colors(5, start = 0.9, end = 0.3), main = "Q4: How frequently did you experience a big change in code readability \n(positive or negative) in the projects you worked on?")
#my.table <- c("Never", "Between 0% and 25%", "Between 25% and 50%", "Between 50% and 75%", "More than 75%")
legend("topright", legend = my.table,
       col=palette[2:3],
       lty=15, lwd=15, cex = 2,
       inset = .02, x.intersp = -0.5)

