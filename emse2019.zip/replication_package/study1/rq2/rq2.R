stratified_sample <- read.csv("study1/rq2/rq2.csv", sep = ",", stringsAsFactors = FALSE)

#ACCURACY OF THE TOOLs
#Calculate the percentage of agree and disagree
readable_unreadable <- stratified_sample[(stratified_sample$from_state == "readable") & (stratified_sample$to_state == "unreadable"), ]
readable_readable <- stratified_sample[(stratified_sample$from_state == "readable") & (stratified_sample$to_state == "readable"), ]
unreadable_readable <- stratified_sample[(stratified_sample$from_state == "unreadable") & (stratified_sample$to_state == "readable"), ]
unreadable_unreadable <- stratified_sample[(stratified_sample$from_state == "unreadable") & (stratified_sample$to_state == "unreadable"), ]
created_readable <- stratified_sample[(stratified_sample$from_state == "created") & (stratified_sample$to_state == "readable"), ]
created_unreadable <- stratified_sample[(stratified_sample$from_state == "created") & (stratified_sample$to_state == "unreadable"), ]
renamed_readable <- stratified_sample[(stratified_sample$from_state == "renamed") & (stratified_sample$to_state == "readable"), ]
renamed_unreadable <- stratified_sample[(stratified_sample$from_state == "renamed") & (stratified_sample$to_state == "unreadable"), ]

num_transition_tot <- (nrow(readable_readable) + nrow(readable_unreadable) + nrow(unreadable_readable) + nrow(unreadable_unreadable)) * 2

num_agree_R_U <- length(which(readable_unreadable$Definitive.pre == "AGREE")) + length(which(readable_unreadable$Definitive.post == "AGREE"))
num_agree_R_R <- length(which(readable_readable$Definitive.pre == "AGREE")) + length(which(readable_readable$Definitive.post == "AGREE"))
num_agree_U_R <- length(which(unreadable_readable$Definitive.pre == "AGREE")) + length(which(unreadable_readable$Definitive.post == "AGREE"))
num_agree_U_U <- length(which(unreadable_unreadable$Definitive.pre == "AGREE")) + length(which(unreadable_unreadable$Definitive.post == "AGREE"))

num_agree_tot <- num_agree_R_U + num_agree_R_R + num_agree_U_R + num_agree_U_U

num_disagree_R_U <- length(which(readable_unreadable$Definitive.pre == "DISAGREE")) + length(which(readable_unreadable$Definitive.post == "DISAGREE"))
num_disagree_R_R <- length(which(readable_readable$Definitive.pre == "DISAGREE")) + length(which(readable_readable$Definitive.post == "DISAGREE"))
num_disagree_U_R <- length(which(unreadable_readable$Definitive.pre == "DISAGREE")) + length(which(unreadable_readable$Definitive.post == "DISAGREE"))
num_disagree_U_U <- length(which(unreadable_unreadable$Definitive.pre == "DISAGREE")) + length(which(unreadable_unreadable$Definitive.post == "DISAGREE"))

num_disagree_tot <- num_disagree_R_U + num_disagree_R_R + num_disagree_U_R + num_disagree_U_U

percentage_agree <- num_agree_tot/num_transition_tot
percentage_agree
#agree: 82%

percentage_disagree <- num_disagree_tot/num_transition_tot
percentage_disagree
#disagree: 17%

error_for_transition <- data.frame(from_state = character(),
                                   to_state = character(),
                                   error = numeric(),
                                   stringsAsFactors = FALSE)
error_for_transition[1, ] <- c(from_state = "readable", to_state = "readable", error = 0.00)
error_for_transition[2, ] <- c(from_state = "readable", to_state = "unreadable", error = 0.00)
error_for_transition[3, ] <- c(from_state = "unreadable", to_state = "readable", error = 0.00)
error_for_transition[4, ] <- c(from_state = "unreadable", to_state = "unreadable", error = 0.00)
error_for_transition[5, ] <- c(from_state = "created", to_state = "readable", error = 0.00)
error_for_transition[6, ] <- c(from_state = "created", to_state = "unreadable", error = 0.00)
error_for_transition[7, ] <- c(from_state = "renamed", to_state = "readable", error = 0.00)
error_for_transition[8, ] <- c(from_state = "renamed", to_state = "unreadable", error = 0.00)
error_for_transition$num_occurences <- 0
error_for_transition$num_disagree <- 0

for(i in 1:nrow(error_for_transition)){
  error_for_transition$num_occurences[i] <- length(which((stratified_sample$from_state == error_for_transition$from_state[i]) & (stratified_sample$to_state == error_for_transition$to_state[i])))
}

for(i in 1:nrow(error_for_transition)){
  dataset <- stratified_sample[(stratified_sample$from_state == error_for_transition$from_state[i]) & (stratified_sample$to_state == error_for_transition$to_state[i]), ]
  print(i)
  print(error_for_transition$from_state[i])
  print(error_for_transition$to_state[i])
  
  for(j in 1:nrow(dataset)){
    if((dataset$Definitive.pre[j] == "DISAGREE") || (dataset$Definitive.post[j] == "DISAGREE")){
      error_for_transition$num_disagree[i] <- error_for_transition$num_disagree[i] + 1  
    }
  }
  print(error_for_transition$num_disagree[i])
  error_for_transition$error[i] <- error_for_transition$num_disagree[i]/error_for_transition$num_occurences[i]
}

#####Confusion matrix on the whole evaluated sample
stratified_sample$state_real_pre <- NA
stratified_sample$state_real_post <- NA
for(i in 1:nrow(stratified_sample)){
  if((stratified_sample$from_state[i] == "created") || (stratified_sample$from_state[i] == "renamed")){
    stratified_sample$state_real_pre[i] <- stratified_sample$from_state[i]
  }
  
  if((stratified_sample$from_state[i] == "readable") && (stratified_sample$Definitive.pre[i] == "AGREE")){
    stratified_sample$state_real_pre[i] <- "readable"
  } else {
    if((stratified_sample$from_state[i] == "readable") && (stratified_sample$Definitive.pre[i] == "DISAGREE")){
      stratified_sample$state_real_pre[i] <- "unreadable" 
    } else {
      if((stratified_sample$from_state[i] == "unreadable") && (stratified_sample$Definitive.pre[i] == "AGREE")){
        stratified_sample$state_real_pre[i] <- "unreadable"
      } else {
        if((stratified_sample$from_state[i] == "unreadable") && (stratified_sample$Definitive.pre[i] == "DISAGREE")){
          stratified_sample$state_real_pre[i] <- "readable"
        }
      }
    }
  }
  
  if((stratified_sample$to_state[i] == "readable") && (stratified_sample$Definitive.post[i] == "AGREE")){
    stratified_sample$state_real_post[i] <- "readable"
  } else {
    if((stratified_sample$to_state[i] == "readable") && (stratified_sample$Definitive.post[i] == "DISAGREE")){
      stratified_sample$state_real_post[i] <- "unreadable" 
    } else {
      if((stratified_sample$to_state[i] == "unreadable") && (stratified_sample$Definitive.post[i] == "AGREE")){
        stratified_sample$state_real_post[i] <- "unreadable"
      } else {
        if((stratified_sample$to_state[i] == "unreadable") && (stratified_sample$Definitive.post[i] == "DISAGREE")){
          stratified_sample$state_real_post[i] <- "readable"
        }
      }
    }
  }
}

stratified_sample$label_actual <- NA
stratified_sample$label_real <- NA

for(i in 1:nrow(stratified_sample)){
  if(stratified_sample$from_state[i] == "created"){
    if(stratified_sample$to_state[i] == "readable"){
      stratified_sample$label_actual[i] <- "c-r"
    } else {
      if(stratified_sample$to_state[i] == "unreadable"){
        stratified_sample$label_actual[i] <- "c-u"
      } 
    }
  } else {
    if(stratified_sample$from_state[i] == "renamed"){
      if(stratified_sample$to_state[i] == "readable"){
        stratified_sample$label_actual[i] <- "n-r"
      } else {
        if(stratified_sample$to_state[i] == "unreadable"){
          stratified_sample$label_actual[i] <- "n-u"
        } 
      }
    } else {
      if(stratified_sample$from_state[i] == "readable"){
        if(stratified_sample$to_state[i] == "readable"){
          stratified_sample$label_actual[i] <- "r-r"
        } else {
          if(stratified_sample$to_state[i] == "unreadable"){
            stratified_sample$label_actual[i] <- "r-u"
          } 
        }
      } else {
        if(stratified_sample$from_state[i] == "unreadable"){
          if(stratified_sample$to_state[i] == "readable"){
            stratified_sample$label_actual[i] <- "u-r"
          } else {
            if(stratified_sample$to_state[i] == "unreadable"){
              stratified_sample$label_actual[i] <- "u-u"
            } 
          }
        }
      }
    }
  }
  
  if(stratified_sample$state_real_pre[i] == "created"){
    if(stratified_sample$state_real_post[i] == "readable"){
      stratified_sample$label_real[i] <- "c-r"
    } else {
      if(stratified_sample$state_real_post[i] == "unreadable"){
        stratified_sample$label_real[i] <- "c-u"
      } 
    }
  } else {
    if(stratified_sample$state_real_pre[i] == "renamed"){
      if(stratified_sample$state_real_post[i] == "readable"){
        stratified_sample$label_real[i] <- "n-r"
      } else {
        if(stratified_sample$state_real_post[i] == "unreadable"){
          stratified_sample$label_real[i] <- "n-u"
        } 
      }
    } else {
      if(stratified_sample$state_real_pre[i] == "readable"){
        if(stratified_sample$state_real_post[i] == "readable"){
          stratified_sample$label_real[i] <- "r-r"
        } else {
          if(stratified_sample$state_real_post[i] == "unreadable"){
            stratified_sample$label_real[i] <- "r-u"
          } 
        }
      } else {
        if(stratified_sample$state_real_pre[i] == "unreadable"){
          if(stratified_sample$state_real_post[i] == "readable"){
            stratified_sample$label_real[i] <- "u-r"
          } else {
            if(stratified_sample$state_real_post[i] == "unreadable"){
              stratified_sample$label_real[i] <- "u-u"
            } 
          }
        }
      }
    }
  }
}

matrix <- matrix(data = c(rep(0, 64)), byrow = T, ncol = 8)
row.names(matrix) <- c("r-r", "r-u", "u-r", "u-u", "c-r", "c-u", "n-r", "n-u")
colnames(matrix) <- c("r-r", "r-u", "u-r", "u-u", "c-r", "c-u", "n-r", "n-u")
matrix

###Performance of the tool in transition classification
for(i in 1:nrow(stratified_sample)){
  matrix[stratified_sample$label_actual[i], stratified_sample$label_real[i]] <- matrix[stratified_sample$label_actual[i], stratified_sample$label_real[i]] + 1
}

precision_total <- data.frame(label_transition1 = character(),
                              label_transition2 = character(),
                              precision = numeric(),
                              stringsAsFactors = FALSE)
precision_row <- data.frame(label_transition1 = character(),
                            label_transition2 = character(),
                            precision = numeric(),
                            stringsAsFactors = FALSE)


recall_total <- data.frame(label_transition1 = character(),
                           label_transition2 = character(),
                           recall = numeric(),
                           stringsAsFactors = FALSE)
recall_row <- data.frame(label_transition1 = character(),
                         label_transition2 = character(),
                         recall = numeric(),
                         stringsAsFactors = FALSE)

fmeasure_total <- data.frame(label_transition1 = character(),
                             label_transition2 = character(),
                             fmeasure = numeric(),
                             stringsAsFactors = FALSE)
fmeasure_row <- data.frame(label_transition1 = character(),
                           label_transition2 = character(),
                           fmeasure = numeric(),
                           stringsAsFactors = FALSE)


labels <- c("r-r", "r-u", "u-r", "u-u", "c-r", "c-u", "n-r", "n-u")
labels1 <- c("r-r", "r-u", "u-r", "u-u", "c-r", "c-u", "n-r", "n-u")

for(i in 1:length(labels)){
  for(j in 1:length(labels1)){
    precision_row[1, ] <- c(labels[i], labels1[j], 0.00)
    precision_total <- rbind(precision_total, precision_row)
    recall_row[1, ] <- c(labels[i], labels1[j], 0.00)
    recall_total <- rbind(recall_total, recall_row)
    fmeasure_row[1, ] <- c(labels[i], labels1[j], 0.00)
    fmeasure_total <- rbind(fmeasure_total, fmeasure_row)
  }
}

for(i in 1:length(labels)){
  for(j in 1:length(labels1)){
    tp <- matrix[i, j]
    fp <- sum(matrix[i, ]) - tp
    fn <- sum(matrix[, j]) - tp
    k1 <- which((precision_total$label_transition1 == labels[i]) & (precision_total$label_transition2 == labels1[j]))
    precision_total$precision[k1] <- tp/(tp+fp)
    k2 <- which((recall_total$label_transition1 == labels[i]) & (recall_total$label_transition2 == labels1[j]))
    recall_total$recall[k2] <- tp/(tp+fn)
    k3 <- which((fmeasure_total$label_transition1 == labels[i]) & (fmeasure_total$label_transition2 == labels1[j]))
    fmeasure_total$fmeasure[k3] <- 2*((as.numeric(precision_total$precision[k1]) * as.numeric(recall_total$recall[k2])) / (as.numeric(precision_total$precision[k1]) + as.numeric(recall_total$recall[k2])))
  }
}
confusion_matrix_stratified_sample <- matrix

precision_total <- precision_total[precision_total$label_transition1 == precision_total$label_transition2, ]
precision_total <- precision_total[ , -2]
colnames(precision_total)[colnames(precision_total)=="label_transition1"] <- "label_transition"

recall_total <- recall_total[recall_total$label_transition1 == recall_total$label_transition2, ]
recall_total <- recall_total[ , -2]
colnames(recall_total)[colnames(recall_total)=="label_transition1"] <- "label_transition"

fmeasure_total <- fmeasure_total[fmeasure_total$label_transition1 == fmeasure_total$label_transition2, ]
fmeasure_total <- fmeasure_total[ , -2]
colnames(fmeasure_total)[colnames(fmeasure_total)=="label_transition1"] <- "label_transition"

precision_recall_total <- merge(precision_total, recall_total, by.x = "label_transition", by.y = "label_transition")
precision_recall_total <- merge(precision_recall_total, fmeasure_total, by.x = "label_transition", by.y = "label_transition")

#BOOTSTRAPPING
library(boot)

precision_10000 <- precision_total
recall_10000 <- recall_total
fmeasure_10000 <- fmeasure_total
num_repetitions <- 10000
for(i in 1:num_repetitions){
  subsample <- stratified_sample[sample(nrow(stratified_sample), size = nrow(stratified_sample), replace = TRUE), ]
  
  for(j in 1:nrow(subsample)){
    matrix[subsample$label_actual[j], subsample$label_real[j]] <- matrix[subsample$label_actual[j], subsample$label_real[j]] + 1
  }
  
  precision_bootstrap <- data.frame(label_transition1 = character(), label_transition2 = character(), precision = numeric(), stringsAsFactors = FALSE)
  recall_bootstrap <- data.frame(label_transition1 = character(), label_transition2 = character(), recall = numeric(),stringsAsFactors = FALSE)
  fmeasure_bootstrap <- data.frame(label_transition1 = character(), label_transition2 = character(), fmeasure = numeric(),stringsAsFactors = FALSE)
  
  for(j in 1:length(labels)){
    for(k in 1:length(labels1)){
      precision_row[1, ] <- c(labels[j], labels1[k], 0.00)
      precision_bootstrap <- rbind(precision_bootstrap, precision_row)
      recall_row[1, ] <- c(labels[j], labels1[k], 0.00)
      recall_bootstrap <- rbind(recall_bootstrap, recall_row)
      fmeasure_row[1, ] <- c(labels[j], labels1[k], 0.00)
      fmeasure_bootstrap <- rbind(fmeasure_bootstrap, fmeasure_row)
    }
  }
  
  for(j in 1:length(labels)){
    for(k in 1:length(labels1)){
      tp <- matrix[j, k]
      fp <- sum(matrix[j, ]) - tp
      fn <- sum(matrix[, k]) - tp
      z1 <- which((precision_bootstrap$label_transition1 == labels[j]) & (precision_bootstrap$label_transition2 == labels1[k]))
      precision_bootstrap$precision[z1] <- tp/(tp+fp)
      z2 <- which((recall_bootstrap$label_transition1 == labels[j]) & (recall_bootstrap$label_transition2 == labels1[k]))
      recall_bootstrap$recall[z2] <- tp/(tp+fn)
      z3 <- which((fmeasure_bootstrap$label_transition1 == labels[j]) & (fmeasure_bootstrap$label_transition2 == labels1[k]))
      fmeasure_bootstrap$fmeasure[z3] <- 2*((as.numeric(precision_bootstrap$precision[z1]) * as.numeric(recall_bootstrap$recall[z2])) / (as.numeric(precision_bootstrap$precision[z1]) + as.numeric(recall_bootstrap$recall[z2])))
    }
  }
  
  precision_bootstrap <- precision_bootstrap[precision_bootstrap$label_transition1 == precision_bootstrap$label_transition2, ]
  precision_bootstrap <- precision_bootstrap[ , -2]
  colnames(precision_bootstrap)[colnames(precision_bootstrap) == "precision"] <- paste(c("precision_bootstrap_", i), collapse = "")
  
  recall_bootstrap <- recall_bootstrap[recall_bootstrap$label_transition1 == recall_bootstrap$label_transition2, ]
  recall_bootstrap <- recall_bootstrap[ , -2]
  colnames(recall_bootstrap)[colnames(recall_bootstrap) == "recall"] <- paste(c("recall_bootstrap_", i), collapse = "")
  
  fmeasure_bootstrap <- fmeasure_bootstrap[fmeasure_bootstrap$label_transition1 == fmeasure_bootstrap$label_transition2, ]
  fmeasure_bootstrap <- fmeasure_bootstrap[ , -2]
  colnames(fmeasure_bootstrap)[colnames(fmeasure_bootstrap) == "fmeasure"] <- paste(c("fmeasure_bootstrap_", i), collapse = "")
  
  precision_10000 <- merge(precision_10000, precision_bootstrap, by.x = "label_transition", by.y = "label_transition1")
  recall_10000 <- merge(recall_10000, recall_bootstrap, by.x = "label_transition", by.y = "label_transition1")
  fmeasure_10000 <- merge(fmeasure_10000, fmeasure_bootstrap, by.x = "label_transition", by.y = "label_transition1")
  
  print(num_repetitions)
  num_repetitions <- num_repetitions - 1
}

precision_10000$precision_mean <- 0.00
precision_10000$precision_lowq <- 0.00
precision_10000$precision_highq <- 0.00
precision_10000$precision_sum <- 0.00
precision_10000$precision_var <- 0.00
precision_10000$precision_sd <- 0.00
for(i in 1:nrow(precision_10000)){
  precision_10000$precision_mean[i] <- mean(as.numeric(precision_10000[i, 3:10002]))
  precision_10000$precision_lowq[i] <- quantile(as.numeric(precision_10000[i, 3:10002]), c(0.05, 0.95))[[1]][1]
  precision_10000$precision_highq[i] <- quantile(as.numeric(precision_10000[i, 3:10002]), c(0.05, 0.95))[[2]][1]
  precision_10000$precision_sum[i] <- sum(as.numeric(precision_10000[i, 3:10002]))
  precision_10000$precision_var[i] <- var(as.numeric(precision_10000[i, 3:10002]))
  precision_10000$precision_sd[i] <- sd(as.numeric(precision_10000[i, 3:10002]))
}
summary_precision_10000 <- subset(precision_10000, select = c("label_transition", "precision_mean", "precision_lowq", "precision_highq"))

recall_10000$recall_mean <- 0.00
recall_10000$recall_lowq <- 0.00
recall_10000$recall_highq <- 0.00
recall_10000$recall_sum <- 0.00
recall_10000$recall_var <- 0.00
recall_10000$recall_sd <- 0.00
for(i in 1:nrow(recall_10000)){
  recall_10000$recall_mean[i] <- mean(as.numeric(recall_10000[i, 3:10002]))
  recall_10000$recall_lowq[i] <- quantile(as.numeric(recall_10000[i, 3:10002]), c(0.05, 0.95))[[1]][1]
  recall_10000$recall_highq[i] <- quantile(as.numeric(recall_10000[i, 3:10002]), c(0.05, 0.95))[[2]][1]
  recall_10000$recall_sum[i] <- sum(as.numeric(recall_10000[i, 3:10002]))
  recall_10000$recall_var[i] <- var(as.numeric(recall_10000[i, 3:10002]))
  recall_10000$recall_sd[i] <- sd(as.numeric(recall_10000[i, 3:10002]))
}
summary_recall_10000 <- subset(recall_10000, select = c("label_transition", "recall_mean", "recall_lowq", "recall_highq"))

fmeasure_10000$fmeasure_mean <- 0.00
fmeasure_10000$fmeasure_lowq <- 0.00
fmeasure_10000$fmeasure_highq <- 0.00
fmeasure_10000$fmeasure_sum <- 0.00
fmeasure_10000$fmeasure_var <- 0.00
fmeasure_10000$fmeasure_sd <- 0.00
for(i in 1:nrow(fmeasure_10000)){
  fmeasure_10000$fmeasure_mean[i] <- mean(as.numeric(fmeasure_10000[i, 3:10002]))
  fmeasure_10000$fmeasure_lowq[i] <- quantile(as.numeric(fmeasure_10000[i, 3:10002]), c(0.05, 0.95))[[1]][1]
  fmeasure_10000$fmeasure_highq[i] <- quantile(as.numeric(fmeasure_10000[i, 3:10002]), c(0.05, 0.95))[[2]][1]
  fmeasure_10000$fmeasure_sum[i] <- sum(as.numeric(fmeasure_10000[i, 3:10002]))
  fmeasure_10000$fmeasure_var[i] <- var(as.numeric(fmeasure_10000[i, 3:10002]))
  fmeasure_10000$fmeasure_sd[i] <- sd(as.numeric(fmeasure_10000[i, 3:10002]))
}
summary_fmeasure_10000 <- subset(fmeasure_10000, select = c("label_transition", "fmeasure_mean", "fmeasure_lowq", "fmeasure_highq"))

precision_recall_10000 <- merge(summary_precision_10000, summary_recall_10000, by.x = "label_transition", by.y = "label_transition")
precision_recall_10000 <- merge(precision_recall_10000, summary_fmeasure_10000, by.x = "label_transition", by.y = "label_transition")
precision_recall_10000
