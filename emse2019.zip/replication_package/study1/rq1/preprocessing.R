#EXTRACT RANGE FROM DATASET PANTIUCHINA
pantiunchina_dataset<-read.table("study1/rq1/pantiuchina_dataset.csv",sep=",",header=TRUE)
temp <- pantiunchina_dataset[pantiunchina_dataset$metric_name == "readability-s", ]
data_s <- subset(temp, select = c(system, commit_id, class_name))
data_s <- data_s[!duplicated(data_s), ]
data_s$before <- NA
data_s$after <- NA

for(i in 1:nrow(data_s)){
  before <- which(temp$system == data_s$system[i] 
                  & temp$commit_id == data_s$commit_id[i]
                  & temp$class_name == data_s$class_name[i]
                  & temp$before_or_after_commit == "before")
  after <- which(temp$system == data_s$system[i] 
                 & temp$commit_id == data_s$commit_id[i]
                 & temp$class_name == data_s$class_name[i]
                 & temp$before_or_after_commit == "after")
  if(length(before) == 1){
    data_s$before[i] <- temp$value[before]  
  }
  if(length(after) == 1){
    data_s$after[i] <- temp$value[after]
  }
}

#Unreadable -> Readable
data_s1 <- data_s[data_s$before< 0.5 & data_s$after>0.5, ]
data_s1 <- data_s1[complete.cases(data_s1), ]

#Readable -> Unreadable
data_s2 <- data_s[data_s$before > 0.5 & data_s$after < 0.5, ]
data_s2 <- data_s2[complete.cases(data_s2), ]
data_s2_1 <- data_s2[-c(12, 13, 15), ]
max(data_s2_1$before)
min(data_s2_1$after)
